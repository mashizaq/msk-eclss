#!/usr/bin/env python3
"""
ARIA Desktop — Language API Module
Supports: Language Detection, Translation, Multi-language NLP,
          Localized TTS, Language Switching, Dialect Handling
"""

import re
import json
import math
import random
import logging
from datetime import datetime

log = logging.getLogger('ARIA.Language')

# ── Language Registry ─────────────────────────────────────────────────────────

LANGUAGES = {
    "en":    {"name": "English",    "native": "English",         "tts": "en-US", "rtl": False},
    "sw":    {"name": "Swahili",    "native": "Kiswahili",       "tts": "sw-KE", "rtl": False},
    "fr":    {"name": "French",     "native": "Français",        "tts": "fr-FR", "rtl": False},
    "ar":    {"name": "Arabic",     "native": "العربية",          "tts": "ar-SA", "rtl": True },
    "zh":    {"name": "Chinese",    "native": "中文",             "tts": "zh-CN", "rtl": False},
    "es":    {"name": "Spanish",    "native": "Español",         "tts": "es-ES", "rtl": False},
    "hi":    {"name": "Hindi",      "native": "हिन्दी",           "tts": "hi-IN", "rtl": False},
    "pt":    {"name": "Portuguese", "native": "Português",       "tts": "pt-BR", "rtl": False},
    "de":    {"name": "German",     "native": "Deutsch",         "tts": "de-DE", "rtl": False},
    "ja":    {"name": "Japanese",   "native": "日本語",           "tts": "ja-JP", "rtl": False},
    "ko":    {"name": "Korean",     "native": "한국어",           "tts": "ko-KR", "rtl": False},
    "ru":    {"name": "Russian",    "native": "Русский",         "tts": "ru-RU", "rtl": False},
    "it":    {"name": "Italian",    "native": "Italiano",        "tts": "it-IT", "rtl": False},
    "nl":    {"name": "Dutch",      "native": "Nederlands",      "tts": "nl-NL", "rtl": False},
    "tr":    {"name": "Turkish",    "native": "Türkçe",          "tts": "tr-TR", "rtl": False},
    "pl":    {"name": "Polish",     "native": "Polski",          "tts": "pl-PL", "rtl": False},
    "vi":    {"name": "Vietnamese", "native": "Tiếng Việt",      "tts": "vi-VN", "rtl": False},
    "th":    {"name": "Thai",       "native": "ไทย",             "tts": "th-TH", "rtl": False},
    "fa":    {"name": "Persian",    "native": "فارسی",           "tts": "fa-IR", "rtl": True },
    "he":    {"name": "Hebrew",     "native": "עברית",           "tts": "he-IL", "rtl": True },
    "id":    {"name": "Indonesian", "native": "Bahasa Indonesia","tts": "id-ID", "rtl": False},
    "ms":    {"name": "Malay",      "native": "Bahasa Melayu",   "tts": "ms-MY", "rtl": False},
    "uk":    {"name": "Ukrainian",  "native": "Українська",      "tts": "uk-UA", "rtl": False},
    "bn":    {"name": "Bengali",    "native": "বাংলা",           "tts": "bn-BD", "rtl": False},
    "ur":    {"name": "Urdu",       "native": "اردو",            "tts": "ur-PK", "rtl": True },
    "ta":    {"name": "Tamil",      "native": "தமிழ்",           "tts": "ta-IN", "rtl": False},
    "yo":    {"name": "Yoruba",     "native": "Yorùbá",          "tts": "yo-NG", "rtl": False},
    "ha":    {"name": "Hausa",      "native": "Hausa",           "tts": "ha-NG", "rtl": False},
    "am":    {"name": "Amharic",    "native": "አማርኛ",           "tts": "am-ET", "rtl": False},
    "so":    {"name": "Somali",     "native": "Soomaali",        "tts": "so-SO", "rtl": False},
}

# ── Language Detection ────────────────────────────────────────────────────────

LANG_FINGERPRINTS = {
    "en": {"the","is","are","was","were","have","has","been","will","would","could","should","this","that","with","from","they","their","what","when","where","how","why","who"},
    "sw": {"na","ni","ya","wa","kwa","za","la","katika","hii","hilo","kwamba","pia","sana","lakini","kama","yake","wake","wao","mimi","wewe","yeye","sisi","ninyi","wao"},
    "fr": {"le","la","les","de","du","des","un","une","est","sont","être","avoir","avec","dans","pour","que","qui","ne","pas","plus","aussi","mais","ou","et"},
    "ar": {"من","في","على","إلى","عن","مع","هذا","هذه","التي","الذي","كان","كانت","لا","ما","هو","هي"},
    "zh": {"的","了","在","是","我","有","和","就","不","人","都","一","上","也","你","他"},
    "es": {"el","la","los","las","de","del","un","una","es","son","ser","estar","con","en","para","que","no","por","más","también"},
    "de": {"der","die","das","ein","eine","ist","sind","war","werden","haben","mit","von","für","auf","nicht","auch","als","noch"},
    "pt": {"o","a","os","as","de","do","da","um","uma","é","são","ser","estar","com","em","para","que","não"},
    "hi": {"है","हैं","था","थे","और","में","से","को","के","की","का","एक","यह","वह","होना"},
    "ru": {"и","в","на","не","что","это","как","с","а","он","она","они","мы","вы","за","но"},
    "ja": {"は","が","を","に","で","の","と","も","か","た","て","して","から","まで","より"},
    "ko": {"이","가","을","를","에","의","는","은","로","으로","도","와","과","하다","있다"},
    "it": {"il","la","i","le","di","del","della","un","una","è","sono","essere","con","in","per","che"},
    "tr": {"ve","bir","bu","için","ile","de","da","den","dan","ne","bu","şu","o","ki","var"},
}

class LanguageDetector:
    def detect(self, text: str) -> dict:
        if not text.strip():
            return {"lang": "en", "confidence": 0.0, "name": "English"}

        # Script-based detection first (high confidence)
        if re.search(r'[\u0600-\u06FF]', text):
            # Arabic/Urdu/Persian — check for specific letters
            if re.search(r'[پچژگ]', text):
                return {"lang": "fa", "confidence": 0.92, "name": "Persian"}
            if re.search(r'[ٹڈڑ]', text):
                return {"lang": "ur", "confidence": 0.91, "name": "Urdu"}
            return {"lang": "ar", "confidence": 0.93, "name": "Arabic"}

        if re.search(r'[\u4E00-\u9FFF]', text):
            return {"lang": "zh", "confidence": 0.95, "name": "Chinese"}
        if re.search(r'[\u3040-\u309F\u30A0-\u30FF]', text):
            return {"lang": "ja", "confidence": 0.95, "name": "Japanese"}
        if re.search(r'[\uAC00-\uD7AF]', text):
            return {"lang": "ko", "confidence": 0.95, "name": "Korean"}
        if re.search(r'[\u0900-\u097F]', text):
            return {"lang": "hi", "confidence": 0.93, "name": "Hindi"}
        if re.search(r'[\u0400-\u04FF]', text):
            return {"lang": "ru", "confidence": 0.92, "name": "Russian"}
        if re.search(r'[\u0590-\u05FF]', text):
            return {"lang": "he", "confidence": 0.93, "name": "Hebrew"}
        if re.search(r'[\u0E00-\u0E7F]', text):
            return {"lang": "th", "confidence": 0.94, "name": "Thai"}
        if re.search(r'[\u1200-\u137F]', text):
            return {"lang": "am", "confidence": 0.93, "name": "Amharic"}

        # Word-frequency fingerprint for Latin-script languages
        words = set(re.findall(r'\b\w+\b', text.lower()))
        if not words:
            return {"lang": "en", "confidence": 0.5, "name": "English"}

        scores = {}
        for lang, fingerprint in LANG_FINGERPRINTS.items():
            overlap = len(words & fingerprint)
            scores[lang] = overlap / max(len(words), 1)

        best = max(scores, key=scores.get)
        conf = min(scores[best] * 3.5, 0.97)

        if scores[best] < 0.02:
            best, conf = "en", 0.55

        info = LANGUAGES.get(best, {})
        return {
            "lang": best,
            "confidence": round(conf, 3),
            "name": info.get("name", best),
            "native_name": info.get("native", best),
            "rtl": info.get("rtl", False),
            "tts_locale": info.get("tts", "en-US"),
            "scores": {k: round(v, 4) for k, v in sorted(scores.items(), key=lambda x: -x[1])[:5]}
        }


# ── Translation Engine ────────────────────────────────────────────────────────

# Phrase dictionaries for common expressions
PHRASE_DICT = {
    # Greetings
    ("en","sw"): {"hello":"habari","good morning":"habari za asubuhi","good evening":"habari za jioni","how are you":"habari yako","thank you":"asante","yes":"ndiyo","no":"hapana","please":"tafadhali","sorry":"samahani","goodbye":"kwaheri","my name is":"ninaitwa","what is your name":"jina lako ni nani","help":"msaada","water":"maji","food":"chakula","time":"wakati","today":"leo","tomorrow":"kesho","i love you":"nakupenda"},
    ("en","fr"): {"hello":"bonjour","good morning":"bonjour","good evening":"bonsoir","how are you":"comment allez-vous","thank you":"merci","yes":"oui","no":"non","please":"s'il vous plaît","sorry":"désolé","goodbye":"au revoir","help":"aide","time":"temps","today":"aujourd'hui","tomorrow":"demain","i love you":"je t'aime"},
    ("en","es"): {"hello":"hola","good morning":"buenos días","good evening":"buenas noches","how are you":"¿cómo estás?","thank you":"gracias","yes":"sí","no":"no","please":"por favor","sorry":"lo siento","goodbye":"adiós","help":"ayuda","time":"tiempo","today":"hoy","tomorrow":"mañana","i love you":"te quiero"},
    ("en","de"): {"hello":"hallo","good morning":"guten morgen","good evening":"guten abend","how are you":"wie geht es ihnen","thank you":"danke","yes":"ja","no":"nein","please":"bitte","sorry":"entschuldigung","goodbye":"auf wiedersehen","help":"hilfe","time":"zeit","today":"heute","tomorrow":"morgen","i love you":"ich liebe dich"},
    ("en","ar"): {"hello":"مرحبا","good morning":"صباح الخير","good evening":"مساء الخير","how are you":"كيف حالك","thank you":"شكرا","yes":"نعم","no":"لا","please":"من فضلك","sorry":"آسف","goodbye":"مع السلامة","help":"مساعدة","time":"وقت","today":"اليوم","tomorrow":"غداً","i love you":"أحبك"},
    ("en","zh"): {"hello":"你好","good morning":"早上好","good evening":"晚上好","how are you":"你好吗","thank you":"谢谢","yes":"是","no":"不","please":"请","sorry":"对不起","goodbye":"再见","help":"帮助","time":"时间","today":"今天","tomorrow":"明天","i love you":"我爱你"},
    ("en","hi"): {"hello":"नमस्ते","good morning":"सुप्रभात","good evening":"शुभ संध्या","how are you":"आप कैसे हैं","thank you":"धन्यवाद","yes":"हाँ","no":"नहीं","please":"कृपया","sorry":"माफ़ करना","goodbye":"अलविदा","help":"मदद","time":"समय","today":"आज","tomorrow":"कल","i love you":"मैं तुमसे प्यार करता हूँ"},
    ("en","pt"): {"hello":"olá","good morning":"bom dia","good evening":"boa noite","how are you":"como vai você","thank you":"obrigado","yes":"sim","no":"não","please":"por favor","sorry":"desculpe","goodbye":"tchau","help":"ajuda","time":"tempo","today":"hoje","tomorrow":"amanhã","i love you":"eu te amo"},
    ("en","ja"): {"hello":"こんにちは","good morning":"おはようございます","good evening":"こんばんは","how are you":"お元気ですか","thank you":"ありがとう","yes":"はい","no":"いいえ","please":"お願いします","sorry":"すみません","goodbye":"さようなら","help":"助けて","time":"時間","today":"今日","tomorrow":"明日","i love you":"愛してる"},
}

class TranslationEngine:
    def __init__(self):
        self.cache = {}
        self.detector = LanguageDetector()

    def translate(self, text: str, target_lang: str, source_lang: str = "auto") -> dict:
        if source_lang == "auto":
            detected = self.detector.detect(text)
            source_lang = detected["lang"]

        if source_lang == target_lang:
            return {"translated": text, "source_lang": source_lang,
                    "target_lang": target_lang, "method": "passthrough", "confidence": 1.0}

        cache_key = f"{source_lang}:{target_lang}:{text[:50]}"
        if cache_key in self.cache:
            return self.cache[cache_key]

        # Try phrase dictionary
        dict_key = (source_lang, target_lang)
        rev_key  = (target_lang, source_lang)
        phrase_dict = PHRASE_DICT.get(dict_key) or self._reverse_dict(PHRASE_DICT.get(rev_key))

        if phrase_dict:
            translated = self._translate_phrases(text, phrase_dict)
            if translated != text:
                result = {
                    "translated": translated,
                    "source_lang": source_lang,
                    "target_lang": target_lang,
                    "source_name": LANGUAGES.get(source_lang, {}).get("name", source_lang),
                    "target_name": LANGUAGES.get(target_lang, {}).get("name", target_lang),
                    "method": "phrase_dictionary",
                    "confidence": 0.75,
                    "note": "Partial phrase translation. For full accuracy, Claude API handles complex text."
                }
                self.cache[cache_key] = result
                return result

        # Fallback — return structured response for Claude to handle
        result = {
            "translated": None,
            "source_lang": source_lang,
            "target_lang": target_lang,
            "source_name": LANGUAGES.get(source_lang, {}).get("name", source_lang),
            "target_name": LANGUAGES.get(target_lang, {}).get("name", target_lang),
            "method": "claude_required",
            "confidence": 0.0,
            "prompt": f"Translate the following from {LANGUAGES.get(source_lang,{}).get('name','unknown')} to {LANGUAGES.get(target_lang,{}).get('name','unknown')}. Return ONLY the translated text:\n\n{text}"
        }
        return result

    def _reverse_dict(self, d):
        if not d: return None
        return {v: k for k, v in d.items()}

    def _translate_phrases(self, text: str, phrase_dict: dict) -> str:
        result = text.lower()
        # Sort by length (longest first) to avoid partial replacements
        for src, tgt in sorted(phrase_dict.items(), key=lambda x: -len(x[0])):
            result = result.replace(src.lower(), tgt)
        return result

    def get_language_info(self, code: str) -> dict:
        info = LANGUAGES.get(code, {})
        return {
            "code": code,
            "name": info.get("name", "Unknown"),
            "native_name": info.get("native", code),
            "rtl": info.get("rtl", False),
            "tts_locale": info.get("tts", "en-US"),
            "supported": code in LANGUAGES
        }

    def list_languages(self) -> list:
        return [{"code": k, **v} for k, v in LANGUAGES.items()]


# ── Localization (ARIA UI strings) ────────────────────────────────────────────

UI_STRINGS = {
    "en": {
        "greeting_morning":   "Good morning",
        "greeting_afternoon": "Good afternoon",
        "greeting_evening":   "Good evening",
        "standby":            "STANDBY",
        "listening":          "LISTENING...",
        "speaking":           "ARIA SPEAKING",
        "processing":         "ARIA processing...",
        "mode_assistant":     "Assistant",
        "mode_research":      "Research",
        "mode_creative":      "Creative",
        "mode_analysis":      "Analysis",
        "send":               "Send",
        "clear":              "Clear",
        "settings":           "Settings",
        "update":             "UPDATE",
        "version":            "Version",
        "online":             "ONLINE",
    },
    "sw": {
        "greeting_morning":   "Habari za asubuhi",
        "greeting_afternoon": "Habari za mchana",
        "greeting_evening":   "Habari za jioni",
        "standby":            "SUBIRI",
        "listening":          "SIKILIZA...",
        "speaking":           "ARIA ANASEMA",
        "processing":         "ARIA inafanya kazi...",
        "mode_assistant":     "Msaidizi",
        "mode_research":      "Utafiti",
        "mode_creative":      "Ubunifu",
        "mode_analysis":      "Uchambuzi",
        "send":               "Tuma",
        "clear":              "Futa",
        "settings":           "Mipangilio",
        "update":             "SASISHA",
        "version":            "Toleo",
        "online":             "MTANDAONI",
    },
    "fr": {
        "greeting_morning":   "Bonjour",
        "greeting_afternoon": "Bon après-midi",
        "greeting_evening":   "Bonsoir",
        "standby":            "EN ATTENTE",
        "listening":          "J'ÉCOUTE...",
        "speaking":           "ARIA PARLE",
        "processing":         "ARIA traite...",
        "mode_assistant":     "Assistant",
        "mode_research":      "Recherche",
        "mode_creative":      "Créatif",
        "mode_analysis":      "Analyse",
        "send":               "Envoyer",
        "clear":              "Effacer",
        "settings":           "Paramètres",
        "update":             "METTRE À JOUR",
        "version":            "Version",
        "online":             "EN LIGNE",
    },
    "es": {
        "greeting_morning":   "Buenos días",
        "greeting_afternoon": "Buenas tardes",
        "greeting_evening":   "Buenas noches",
        "standby":            "EN ESPERA",
        "listening":          "ESCUCHANDO...",
        "speaking":           "ARIA HABLA",
        "processing":         "ARIA procesando...",
        "mode_assistant":     "Asistente",
        "mode_research":      "Investigación",
        "mode_creative":      "Creativo",
        "mode_analysis":      "Análisis",
        "send":               "Enviar",
        "clear":              "Borrar",
        "settings":           "Configuración",
        "update":             "ACTUALIZAR",
        "version":            "Versión",
        "online":             "EN LÍNEA",
    },
    "de": {
        "greeting_morning":   "Guten Morgen",
        "greeting_afternoon": "Guten Tag",
        "greeting_evening":   "Guten Abend",
        "standby":            "BEREIT",
        "listening":          "HÖRE ZU...",
        "speaking":           "ARIA SPRICHT",
        "processing":         "ARIA verarbeitet...",
        "mode_assistant":     "Assistent",
        "mode_research":      "Forschung",
        "mode_creative":      "Kreativ",
        "mode_analysis":      "Analyse",
        "send":               "Senden",
        "clear":              "Löschen",
        "settings":           "Einstellungen",
        "update":             "AKTUALISIEREN",
        "version":            "Version",
        "online":             "ONLINE",
    },
    "ar": {
        "greeting_morning":   "صباح الخير",
        "greeting_afternoon": "مساء الخير",
        "greeting_evening":   "مساء النور",
        "standby":            "الاستعداد",
        "listening":          "أستمع...",
        "speaking":           "آريا تتحدث",
        "processing":         "آريا تعالج...",
        "mode_assistant":     "مساعد",
        "mode_research":      "بحث",
        "mode_creative":      "إبداعي",
        "mode_analysis":      "تحليل",
        "send":               "إرسال",
        "clear":              "مسح",
        "settings":           "الإعدادات",
        "update":             "تحديث",
        "version":            "الإصدار",
        "online":             "متصل",
    },
    "zh": {
        "greeting_morning":   "早上好",
        "greeting_afternoon": "下午好",
        "greeting_evening":   "晚上好",
        "standby":            "待机",
        "listening":          "聆听中...",
        "speaking":           "ARIA 正在说话",
        "processing":         "ARIA 处理中...",
        "mode_assistant":     "助手",
        "mode_research":      "研究",
        "mode_creative":      "创意",
        "mode_analysis":      "分析",
        "send":               "发送",
        "clear":              "清除",
        "settings":           "设置",
        "update":             "更新",
        "version":            "版本",
        "online":             "在线",
    },
}

def get_ui_strings(lang_code: str) -> dict:
    return UI_STRINGS.get(lang_code, UI_STRINGS["en"])


# ── Multi-language ARIA System Prompt Builder ─────────────────────────────────

LANG_SYSTEM_ADDON = {
    "sw": "Jibu kwa Kiswahili. Wewe ni ARIA, msaidizi wa AI wa kisasa. Kuwa wa kirafiki, wa kuvutia na wa kusaidia.",
    "fr": "Réponds en français. Tu es ARIA, une assistante IA avancée. Sois chaleureuse, intelligente et utile.",
    "es": "Responde en español. Eres ARIA, una asistente de IA avanzada. Sé cálida, inteligente y útil.",
    "ar": "أجب باللغة العربية. أنت ARIA، مساعدة ذكاء اصطناعي متقدمة. كوني دافئة وذكية ومفيدة.",
    "de": "Antworte auf Deutsch. Du bist ARIA, eine fortschrittliche KI-Assistentin. Sei warm, klug und hilfreich.",
    "zh": "用中文回答。你是ARIA，一个先进的AI助手。要热情、智慧和有帮助。",
    "hi": "हिन्दी में उत्तर दें। आप ARIA हैं, एक उन्नत AI सहायक। गर्मजोशी, बुद्धिमान और सहायक बनें।",
    "pt": "Responda em português. Você é ARIA, uma assistente de IA avançada. Seja calorosa, inteligente e útil.",
    "ja": "日本語で答えてください。あなたはARIAです、高度なAIアシスタントです。温かく、賢く、役立つようにしてください。",
    "ko": "한국어로 답하세요. 당신은 ARIA입니다, 고급 AI 어시스턴트입니다. 따뜻하고 지적이며 도움이 되세요.",
    "ru": "Отвечай на русском языке. Ты ARIA, продвинутый ИИ-ассистент. Будь теплой, умной и полезной.",
    "it": "Rispondi in italiano. Sei ARIA, un'assistente AI avanzata. Sii calorosa, intelligente e utile.",
    "tr": "Türkçe cevap ver. Sen ARIA'sın, gelişmiş bir yapay zeka asistanısın. Sıcak, akıllı ve yardımsever ol.",
}

def build_lang_system_prompt(base_prompt: str, lang_code: str) -> str:
    addon = LANG_SYSTEM_ADDON.get(lang_code, "")
    if addon:
        return base_prompt + f"\n\n**LANGUAGE INSTRUCTION**: {addon}"
    return base_prompt


# ── Flask Routes (appended to main server.py) ─────────────────────────────────

def register_language_routes(app):
    from flask import request, jsonify

    detector   = LanguageDetector()
    translator = TranslationEngine()

    @app.route('/language/detect', methods=['POST'])
    def lang_detect():
        data = request.json
        text = data.get('text', '')
        if not text:
            return jsonify({"error": "No text provided"}), 400
        result = detector.detect(text)
        log.info(f"Detected: {result['lang']} ({result['confidence']:.2f}) — '{text[:30]}'")
        return jsonify(result)

    @app.route('/language/translate', methods=['POST'])
    def lang_translate():
        data = request.json
        text        = data.get('text', '')
        target_lang = data.get('target', 'en')
        source_lang = data.get('source', 'auto')
        if not text:
            return jsonify({"error": "No text provided"}), 400
        result = translator.translate(text, target_lang, source_lang)
        return jsonify(result)

    @app.route('/language/list', methods=['GET'])
    def lang_list():
        return jsonify({"languages": translator.list_languages(), "total": len(LANGUAGES)})

    @app.route('/language/info/<code>', methods=['GET'])
    def lang_info(code):
        return jsonify(translator.get_language_info(code))

    @app.route('/language/ui-strings/<code>', methods=['GET'])
    def lang_ui(code):
        return jsonify({"lang": code, "strings": get_ui_strings(code)})

    @app.route('/language/system-prompt', methods=['POST'])
    def lang_system_prompt():
        data = request.json
        base   = data.get('base_prompt', '')
        lang   = data.get('lang', 'en')
        result = build_lang_system_prompt(base, lang)
        return jsonify({"prompt": result, "lang": lang, "modified": lang != 'en'})

    log.info("Language API routes registered")
