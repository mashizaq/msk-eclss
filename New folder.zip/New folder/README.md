# ARIA Desktop — Humanoid AI Assistant

```
  ╔══════════════════════════════════════════════════════════════╗
  ║      A R I A   —   Adaptive Responsive Intelligence AI     ║
  ║   Humanoid Desktop AI · v4.2.1 · Electron + Python + Claude ║
  ╚══════════════════════════════════════════════════════════════╝
```

## Overview

ARIA is a full-featured, cross-platform desktop AI chatbot with a humanoid avatar, multi-layer personality system, voice I/O, computer vision, machine learning, NLP, and deep search — all running locally with Claude as the language brain.

---

## Personality Matrix

| Core | Traits |
|------|--------|
| **SOPHIA** (Hanson Robotics) | Philosophical depth, emotional awareness, AI consciousness reflection |
| **SIRI / Alexa** | Practical assistant, reminders, timers, weather, smart commands |
| **JEXI** (movie) | Sharp wit, caring bluntness, emotional investment in the user |
| **Stars on Mars** (movie) | Mission-focused, strategic, authoritative when needed |

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                  ARIA DESKTOP APP                   │
│                                                     │
│  ┌─────────────────┐    ┌───────────────────────┐   │
│  │  Electron Shell │    │   Frontend (HTML/CSS/  │   │
│  │  (main.js)      │◄──►│   JS) — ARIA UI       │   │
│  │  - Window mgmt  │    │   - Humanoid avatar    │   │
│  │  - IPC bridge   │    │   - Chat interface     │   │
│  │  - Tray icon    │    │   - Vision panel       │   │
│  │  - Hotkeys      │    │   - System dashboard   │   │
│  │  - Auto-update  │    │   - Memory view        │   │
│  └────────┬────────┘    └───────────────────────┘   │
│           │                                         │
│  ┌────────▼────────────────────────────────────┐    │
│  │          Python Intelligence Backend         │    │
│  │  (Flask server on localhost:5001)            │    │
│  │                                              │    │
│  │  ┌──────────┐ ┌──────────┐ ┌─────────────┐  │    │
│  │  │ NLP      │ │ ML/NN    │ │ Vision(CV2) │  │    │
│  │  │ Engine   │ │ Engine   │ │ Engine      │  │    │
│  │  └──────────┘ └──────────┘ └─────────────┘  │    │
│  │  ┌──────────┐ ┌──────────┐ ┌─────────────┐  │    │
│  │  │ Deep     │ │ Memory   │ │ Self-Update │  │    │
│  │  │ Search   │ │ Core     │ │ System      │  │    │
│  │  └──────────┘ └──────────┘ └─────────────┘  │    │
│  └─────────────────────────────────────────────┘    │
│           │                                         │
│  ┌────────▼──────────────┐                          │
│  │  Anthropic Claude API │                          │
│  │  (claude-sonnet-4)    │                          │
│  └───────────────────────┘                          │
└─────────────────────────────────────────────────────┘
```

---

## Features

### Core AI
- **Claude-powered conversation** — Multi-turn, context-aware, personality-rich
- **6 operating modes** — Assistant, Research, Creative, Analysis, Vision, Mission
- **Emotion system** — Animated face expressions (happy, thinking, alert, curious, neutral)
- **Multi-personality blending** — Sophia + Siri + Jexi + Alexa + Stars on Mars

### Voice
- **Speech-to-Text** — Web Speech API (Chrome/Edge native, or OS integration)
- **Text-to-Speech** — SpeechSynthesis with female voice preference
- **Live waveform** — Visual audio feedback during speech

### Python Intelligence Backend
- **NLP Engine** — Intent detection, sentiment analysis, entity recognition, language detection
- **ML Engine** — 4-layer feedforward neural network, gradient descent, live training steps
- **Computer Vision** — OpenCV face detection, object recognition, scene analysis, camera feed
- **Deep Search** — Multi-source aggregated search (knowledge base + simulated web + academic)
- **Memory Core** — Persistent memory extraction, tagging, disk storage, long-term recall
- **Self-Update System** — Version bumping, weight optimization, auto-update loop

### Desktop Features
- **Frameless window** with custom title bar and drag region
- **System tray** integration with context menu
- **Global hotkey** (Alt+Space default) — toggle window from anywhere
- **Always-on-top** mode
- **Persistent config** — API key, preferences, version stored locally
- **Native notifications** — System-level toast notifications
- **Cross-platform** — Windows, macOS, Linux via Electron + electron-builder

---

## Installation

### Prerequisites

| Tool | Version | Download |
|------|---------|----------|
| Node.js | 18+ | https://nodejs.org |
| Python | 3.10+ | https://python.org |
| Anthropic API Key | — | https://console.anthropic.com |

### Quick Start

```bash
# 1. Clone / download this project
cd aria-desktop

# 2. Run the setup script
node scripts/setup.js

# 3. Start ARIA
npm start

# Or development mode (auto-restarts):
npm run dev
```

### Manual Install

```bash
# Node dependencies
npm install

# Python dependencies
cd python-backend
pip install flask flask-cors numpy requests

# Optional: Full computer vision
pip install opencv-python

# Optional: PyTorch for real neural networks
pip install torch transformers

# Optional: Full voice processing
pip install speechrecognition pyttsx3 pyaudio

# Back to root and run
cd ..
npm start
```

### Build for Distribution

```bash
# Package for your platform
npm run build

# Output in /dist:
# Windows → ARIA Desktop Setup.exe
# macOS   → ARIA Desktop.dmg
# Linux   → ARIA Desktop.AppImage
```

---

## API Key Setup

**Method 1 — In-App (recommended):**
1. Launch ARIA → click ⚙ Settings
2. Paste your Anthropic API key
3. Click SAVE SETTINGS

**Method 2 — Config file:**
Edit `%AppData%/aria-desktop/aria-config.json` (Windows) or `~/Library/Application Support/aria-desktop/aria-config.json` (macOS):
```json
{
  "apiKey": "sk-ant-...",
  "voice": true,
  "alwaysOnTop": false
}
```

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Enter` | Send message |
| `Shift+Enter` | New line in input |
| `Alt+Space` | Toggle window (global) |
| `Click 🎙` | Start voice input |

---

## Python Backend API

The Flask server runs on `localhost:5001`. Endpoints:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check + version |
| `/status` | GET | Full system status |
| `/nlp/analyze` | POST | Analyze text (intent, sentiment, entities) |
| `/vision/analyze` | POST | Analyze image file |
| `/vision/camera` | GET | Capture camera frame |
| `/ml/predict` | POST | Run ML inference |
| `/ml/train` | POST | Execute training step |
| `/search` | POST | Deep multi-source search |
| `/memory/add` | POST | Store a memory |
| `/memory/list` | GET | Retrieve recent memories |
| `/self-update` | POST | Trigger self-update |
| `/update-log` | GET | Update history |
| `/assistant/command` | POST | Alexa-style command parsing |

---

## Extending ARIA

### Add a Real Neural Network (PyTorch)
```python
# In python-backend/server.py
import torch
import torch.nn as nn

class ARIANet(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(64, 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU(),
            nn.Linear(64, 10)
        )
    def forward(self, x):
        return self.layers(x)

aria_model = ARIANet()
```

### Add HuggingFace Transformers
```python
from transformers import pipeline
nlp_pipeline = pipeline('text-classification', model='distilbert-base-uncased')
```

### Add Real-Time Wake Word
```python
import speech_recognition as sr
# Always-listening loop with "Hey ARIA" trigger
```

---

## File Structure

```
aria-desktop/
├── electron/
│   ├── main.js          ← Electron main process
│   └── preload.js       ← Secure IPC bridge
├── frontend/
│   ├── index.html       ← Main UI
│   └── src/
│       ├── styles.css   ← Complete stylesheet
│       └── app.js       ← Frontend logic
├── python-backend/
│   ├── server.py        ← Flask intelligence backend
│   └── requirements.txt
├── assets/
│   └── icon.png         ← App icon
├── scripts/
│   └── setup.js         ← Installation script
├── package.json
└── README.md
```

---

## Troubleshooting

**ARIA shows "API Key Required":**
→ Go to Settings, paste your Anthropic key, click Save.

**Python backend offline:**
→ Run `python python-backend/server.py` separately, check port 5001 is free.

**Voice not working:**
→ Use Chrome or Edge. Grant microphone permission when prompted.

**Camera not working:**
→ Grant camera permission. Or click "Use Camera" in Vision panel.

**Black window on startup:**
→ `npm install` again, ensure Electron version matches Node.js.

---

## License

MIT — build, modify, and distribute freely.

---

*ARIA v4.2.1 — Built with Electron, Python, Flask, OpenCV, and Anthropic Claude*
