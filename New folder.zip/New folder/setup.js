#!/usr/bin/env node
/**
 * ARIA Desktop — Setup Script
 * Installs all dependencies and prepares the app for launch
 */

const { execSync, spawnSync } = require('child_process');
const fs   = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const CLR  = { reset:'\x1b[0m', cyan:'\x1b[36m', green:'\x1b[32m', red:'\x1b[31m', yellow:'\x1b[33m', bold:'\x1b[1m' };

function log(msg, color = 'cyan') { console.log(`${CLR[color]}${msg}${CLR.reset}`); }
function ok(msg)   { console.log(`${CLR.green}  ✓ ${msg}${CLR.reset}`); }
function warn(msg) { console.log(`${CLR.yellow}  ⚠ ${msg}${CLR.reset}`); }
function err(msg)  { console.log(`${CLR.red}  ✗ ${msg}${CLR.reset}`); }
function run(cmd, cwd = ROOT) {
  try {
    execSync(cmd, { cwd, stdio: 'pipe' });
    return true;
  } catch (e) {
    return false;
  }
}

console.log('\n' + CLR.bold + CLR.cyan);
console.log('  ╔══════════════════════════════════════════╗');
console.log('  ║   ARIA DESKTOP — SETUP & INSTALLATION   ║');
console.log('  ║   Adaptive Responsive Intelligence AI   ║');
console.log('  ╚══════════════════════════════════════════╝');
console.log(CLR.reset);

// ── Node & npm ────────────────────────────────────────────────────────────────
log('\n[1/4] Checking Node.js & npm...');
const nodeVer = process.version;
const major   = parseInt(nodeVer.slice(1));
if (major < 18) {
  err(`Node.js ${nodeVer} detected. ARIA requires Node.js 18+`);
  err('Download: https://nodejs.org/');
  process.exit(1);
} else {
  ok(`Node.js ${nodeVer}`);
}

// ── npm install ───────────────────────────────────────────────────────────────
log('\n[2/4] Installing Node.js dependencies...');
if (run('npm install')) {
  ok('npm packages installed (electron, axios, electron-store...)');
} else {
  err('npm install failed. Check your network connection.');
  process.exit(1);
}

// ── Python ────────────────────────────────────────────────────────────────────
log('\n[3/4] Checking Python environment...');
const pyResult = spawnSync('python', ['--version'], { encoding: 'utf8' });
const py3Result = spawnSync('python3', ['--version'], { encoding: 'utf8' });
const pyCmd = pyResult.status === 0 ? 'python' : py3Result.status === 0 ? 'python3' : null;

if (!pyCmd) {
  warn('Python not found. Python backend features will be disabled.');
  warn('Install Python 3.10+ from https://python.org/');
} else {
  const pyVer = (pyResult.stdout || py3Result.stdout || '').trim();
  ok(pyVer + ' found');

  log('  Installing Python packages (Flask, numpy, requests...)...');
  const pyInstall = run(`${pyCmd} -m pip install -r requirements.txt --quiet`, path.join(ROOT, 'python-backend'));
  if (pyInstall) {
    ok('Python packages installed');
  } else {
    warn('Some Python packages may not have installed. Core features still work.');
  }

  // Optional OpenCV
  log('  Attempting OpenCV install (optional, enables real vision)...');
  const cvInstall = run(`${pyCmd} -m pip install opencv-python --quiet`);
  if (cvInstall) ok('OpenCV installed — Computer Vision fully enabled');
  else warn('OpenCV not installed — Vision runs in simulation mode (install manually: pip install opencv-python)');
}

// ── Assets ────────────────────────────────────────────────────────────────────
log('\n[4/4] Preparing assets...');
const assetsDir = path.join(ROOT, 'assets');
if (!fs.existsSync(assetsDir)) fs.mkdirSync(assetsDir, { recursive: true });

// Write a simple SVG icon if none exists
const iconSvg = path.join(assetsDir, 'icon.svg');
if (!fs.existsSync(iconSvg)) {
  fs.writeFileSync(iconSvg, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">
  <circle cx="64" cy="64" r="62" fill="#050a14" stroke="#00d4ff" stroke-width="2"/>
  <text x="64" y="80" font-family="monospace" font-size="42" font-weight="bold" fill="#00d4ff" text-anchor="middle">A</text>
</svg>`);
  ok('Default icon created');
}

// ── Config template ───────────────────────────────────────────────────────────
const cfgTemplate = path.join(ROOT, 'aria-config-template.json');
if (!fs.existsSync(cfgTemplate)) {
  fs.writeFileSync(cfgTemplate, JSON.stringify({
    apiKey: "YOUR_ANTHROPIC_API_KEY_HERE",
    voice: true,
    alwaysOnTop: false,
    startMinimized: false,
    hotkey: "Alt+Space",
    pythonPort: 5001,
    autoUpdate: true
  }, null, 2));
  ok('Config template created (aria-config-template.json)');
}

// ── Done ──────────────────────────────────────────────────────────────────────
console.log('\n' + CLR.bold + CLR.green);
console.log('  ╔══════════════════════════════════════════╗');
console.log('  ║          ARIA SETUP COMPLETE!           ║');
console.log('  ╚══════════════════════════════════════════╝');
console.log(CLR.reset);

log('\nNext steps:', 'bold');
log('  1. Edit aria-config-template.json → add your Anthropic API key');
log('  2. Start ARIA:   npm start', 'green');
log('  3. Or dev mode:  npm run dev    (launches Python + Electron)', 'green');
log('\nSettings → enter your API key inside the app');
log('Hotkey: Alt+Space to toggle window\n');
