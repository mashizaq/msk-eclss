/**
 * ARIA Desktop — Advanced Voice Engine
 * Features: Wake word detection, continuous listening, voice profiles,
 *           multilingual STT/TTS, noise filtering, command parsing,
 *           voice activity detection, audio visualization
 */

'use strict';

// ── Voice Engine State ────────────────────────────────────────────────────────
const voiceEngine = {
  recognition:      null,
  synthesis:        window.speechSynthesis || null,
  isListening:      false,
  isSpeaking:       false,
  wakeWordActive:   false,
  continuousMode:   false,
  currentVoice:     null,
  voiceProfiles:    {},
  commandHistory:   [],
  audioContext:     null,
  analyserNode:     null,
  micStream:        null,
  wakeWords:        ['hey aria', 'aria', 'hey ari', 'ok aria', 'oi aria'],
  language:         'en-US',
  confidence:       0,
  interimTranscript:'',
  finalTranscript:  '',
  noiseThreshold:   0.15,
  silenceTimeout:   null,
  speakQueue:       [],
  isSpeakBusy:      false,
  volume:           0.85,
  rate:             0.93,
  pitch:            1.08,
  voiceGender:      'female',
};

// ── Voice Profiles ────────────────────────────────────────────────────────────
const VOICE_PROFILES = {
  aria_default: {
    name:    'ARIA Default',
    rate:    0.93,
    pitch:   1.08,
    volume:  0.85,
    gender:  'female',
    prefer:  ['Samantha','Google UK English Female','Karen','Moira','Tessa','Veena'],
  },
  aria_formal: {
    name:    'ARIA Formal',
    rate:    0.88,
    pitch:   1.0,
    volume:  0.9,
    gender:  'female',
    prefer:  ['Google UK English Female','Samantha','Victoria'],
  },
  aria_casual: {
    name:    'ARIA Casual',
    rate:    1.0,
    pitch:   1.15,
    volume:  0.8,
    gender:  'female',
    prefer:  ['Samantha','Allison','Ava'],
  },
  aria_deep: {
    name:    'ARIA Deep',
    rate:    0.82,
    pitch:   0.85,
    volume:  0.9,
    gender:  'neutral',
    prefer:  ['Alex','Google US English','Daniel'],
  },
};

// ── Voice Command Patterns ─────────────────────────────────────────────────────
const VOICE_COMMANDS = [
  { pattern: /^(hey |ok )?aria,?\s+open (settings|configuration)/i,  action: () => switchView('settings'),   reply: "Opening settings." },
  { pattern: /^(hey |ok )?aria,?\s+open (vision|camera)/i,           action: () => switchView('vision'),     reply: "Activating vision module." },
  { pattern: /^(hey |ok )?aria,?\s+open (memory|memories)/i,         action: () => switchView('memory'),     reply: "Opening memory core." },
  { pattern: /^(hey |ok )?aria,?\s+open (system|dashboard)/i,        action: () => switchView('system'),     reply: "Opening system dashboard." },
  { pattern: /^(hey |ok )?aria,?\s+clear (chat|conversation)/i,      action: () => clearChat(),              reply: "Chat cleared." },
  { pattern: /^(hey |ok )?aria,?\s+(self[ -]?update|update yourself)/i, action: () => triggerSelfUpdate(),  reply: "Initiating self-update sequence." },
  { pattern: /^(hey |ok )?aria,?\s+set mode (assistant|research|creative|analysis|vision|mission)/i,
    action: (m) => {
      const mode = m[2].toLowerCase();
      const btn = document.querySelector(`[data-mode="${mode}"]`);
      if (btn) setMode(btn, mode);
    },
    reply: (m) => `Switching to ${m[2]} mode.`
  },
  { pattern: /^(hey |ok )?aria,?\s+stop (speaking|talking)/i,        action: () => voiceEngine.synthesis?.cancel(), reply: null },
  { pattern: /^(hey |ok )?aria,?\s+wake word (on|off)/i,
    action: (m) => toggleWakeWord(m[2] === 'on'),
    reply: (m) => `Wake word detection ${m[2] === 'on' ? 'enabled' : 'disabled'}.`
  },
  { pattern: /^(hey |ok )?aria,?\s+speak (louder|quieter|faster|slower)/i,
    action: (m) => adjustVoice(m[2]),
    reply: (m) => `Voice adjusted: ${m[2]}.`
  },
  { pattern: /^(hey |ok )?aria,?\s+switch (to )?language (\w+)/i,
    action: (m) => { if (window.langAPI) window.langAPI.switch(m[3].toLowerCase()); },
    reply: (m) => `Switching language to ${m[3]}.`
  },
];

// ── Initialization ────────────────────────────────────────────────────────────
function initVoiceEngine() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    appendLog('[VOICE] Speech recognition not supported — use Chrome or Edge');
    return;
  }

  loadVoices();
  buildVoicePanel();
  appendLog('[VOICE] Advanced voice engine initialized');

  // Load preferences
  try {
    const saved = JSON.parse(localStorage.getItem('aria-voice') || '{}');
    if (saved.volume)      voiceEngine.volume      = saved.volume;
    if (saved.rate)        voiceEngine.rate        = saved.rate;
    if (saved.pitch)       voiceEngine.pitch       = saved.pitch;
    if (saved.voiceGender) voiceEngine.voiceGender = saved.voiceGender;
    if (saved.wakeWordActive !== undefined) voiceEngine.wakeWordActive = saved.wakeWordActive;
  } catch {}
}

function loadVoices() {
  const loadFn = () => {
    const voices = voiceEngine.synthesis?.getVoices() || [];
    voiceEngine.voiceProfiles = {};

    for (const [key, profile] of Object.entries(VOICE_PROFILES)) {
      for (const pref of profile.prefer) {
        const match = voices.find(v =>
          v.name.includes(pref) ||
          v.name === pref
        );
        if (match) {
          voiceEngine.voiceProfiles[key] = match;
          break;
        }
      }
      if (!voiceEngine.voiceProfiles[key]) {
        // Fallback: any female/english voice
        const fallback = voices.find(v =>
          (profile.gender === 'female' && /female/i.test(v.name)) ||
          v.lang.startsWith('en')
        );
        if (fallback) voiceEngine.voiceProfiles[key] = fallback;
      }
    }

    voiceEngine.currentVoice = voiceEngine.voiceProfiles['aria_default'];
    renderVoiceProfiles();
    appendLog(`[VOICE] ${voices.length} voices loaded`);
  };

  if (voiceEngine.synthesis?.getVoices().length > 0) loadFn();
  else if (voiceEngine.synthesis) voiceEngine.synthesis.onvoiceschanged = loadFn;
}

// ── Speech Recognition ────────────────────────────────────────────────────────
function createRecognition(continuous = false) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const rec = new SR();
  rec.lang              = window.langAPI ? window.langAPI.getLocale() : 'en-US';
  rec.continuous        = continuous;
  rec.interimResults    = true;
  rec.maxAlternatives   = 3;
  return rec;
}

function startListening(opts = {}) {
  if (voiceEngine.isListening) return;
  const continuous = opts.continuous || voiceEngine.continuousMode;

  voiceEngine.recognition = createRecognition(continuous);
  voiceEngine.finalTranscript   = '';
  voiceEngine.interimTranscript = '';

  voiceEngine.recognition.onstart = () => {
    voiceEngine.isListening = true;
    voiceEngine.confidence  = 0;
    updateVoiceUI('listening');
    appendLog('[VOICE] Listening started');
    if (voiceEngine.audioContext) startAudioVisualization();
  };

  voiceEngine.recognition.onresult = e => {
    voiceEngine.interimTranscript = '';
    voiceEngine.finalTranscript   = '';

    for (const result of e.results) {
      if (result.isFinal) {
        voiceEngine.finalTranscript   += result[0].transcript;
        voiceEngine.confidence         = result[0].confidence;
      } else {
        voiceEngine.interimTranscript += result[0].transcript;
      }
    }

    // Live preview in input
    const input = document.getElementById('msg-input');
    if (input) {
      input.value = voiceEngine.finalTranscript || voiceEngine.interimTranscript;
      autoResize(input);
    }

    // Language auto-detection on transcript
    if (window.langAPI && voiceEngine.finalTranscript.length > 5) {
      const det = window.langAPI.detect(voiceEngine.finalTranscript);
      if (det.confidence > 0.7) window.langAPI.addHistory(det);
    }

    // Wake word check
    if (voiceEngine.wakeWordActive && !continuous) {
      const lower = (voiceEngine.finalTranscript || voiceEngine.interimTranscript).toLowerCase();
      if (voiceEngine.wakeWords.some(w => lower.includes(w))) {
        onWakeWordDetected(lower);
        return;
      }
    }

    // Auto-send on silence (final transcript)
    if (voiceEngine.finalTranscript && !continuous) {
      clearTimeout(voiceEngine.silenceTimeout);
      voiceEngine.silenceTimeout = setTimeout(() => {
        stopListening();
        if (voiceEngine.finalTranscript.trim()) processVoiceInput(voiceEngine.finalTranscript.trim());
      }, 800);
    }
  };

  voiceEngine.recognition.onerror = e => {
    appendLog(`[VOICE] Error: ${e.error}`);
    stopListening();
    if (e.error === 'no-speech') updateVoiceStatus('No speech detected');
  };

  voiceEngine.recognition.onend = () => {
    if (voiceEngine.isListening && continuous) {
      // Restart continuous listening
      setTimeout(() => voiceEngine.recognition?.start(), 300);
    } else {
      stopListening();
    }
  };

  try {
    voiceEngine.recognition.start();
  } catch (e) {
    appendLog('[VOICE] Cannot start: ' + e.message);
  }
}

function stopListening() {
  voiceEngine.isListening = false;
  clearTimeout(voiceEngine.silenceTimeout);
  try { voiceEngine.recognition?.stop(); } catch {}
  updateVoiceUI('standby');
  stopAudioVisualization();

  // Sync with main app
  if (typeof stopRecording === 'function') stopRecording();
}

function processVoiceInput(transcript) {
  appendLog(`[VOICE] Transcript: "${transcript.slice(0, 60)}"`);
  voiceEngine.commandHistory.unshift({ text: transcript, time: new Date().toISOString() });
  voiceEngine.commandHistory = voiceEngine.commandHistory.slice(0, 20);
  refreshCommandHistory();

  // Check for voice commands first
  for (const cmd of VOICE_COMMANDS) {
    const match = transcript.match(cmd.pattern);
    if (match) {
      cmd.action(match);
      const reply = typeof cmd.reply === 'function' ? cmd.reply(match) : cmd.reply;
      if (reply) speakARIA(reply);
      appendLog(`[VOICE] Command: ${transcript.slice(0, 40)}`);
      return;
    }
  }

  // Otherwise send as chat
  const input = document.getElementById('msg-input');
  if (input) input.value = transcript;
  if (typeof sendMsg === 'function') sendMsg();
}

// ── Wake Word ─────────────────────────────────────────────────────────────────
function onWakeWordDetected(transcript) {
  appendLog('[VOICE] Wake word detected!');
  speakARIA("I'm listening.");
  updateVoiceStatus('Wake word detected — listening...');

  // Strip wake word and send remaining text
  let clean = transcript;
  voiceEngine.wakeWords.forEach(w => { clean = clean.replace(new RegExp(w + ',?\\s*', 'i'), ''); });
  clean = clean.trim();
  if (clean.length > 2) processVoiceInput(clean);
}

function toggleWakeWord(enable) {
  voiceEngine.wakeWordActive = enable !== undefined ? enable : !voiceEngine.wakeWordActive;

  const btn = document.getElementById('wake-word-btn');
  if (btn) {
    btn.textContent   = voiceEngine.wakeWordActive ? '🔴 WAKE: ON' : '⚪ WAKE: OFF';
    btn.style.color   = voiceEngine.wakeWordActive ? 'var(--green)' : 'var(--text3)';
    btn.style.borderColor = voiceEngine.wakeWordActive ? 'rgba(0,255,136,0.4)' : 'var(--cyan3)';
  }
  appendLog(`[VOICE] Wake word: ${voiceEngine.wakeWordActive ? 'ON' : 'OFF'}`);
  saveVoicePrefs();

  if (voiceEngine.wakeWordActive) {
    startContinuousListening();
    notify('🎙 "Hey ARIA" wake word active');
  } else {
    stopContinuousListening();
  }
}

let continuousRec = null;
function startContinuousListening() {
  if (continuousRec) return;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return;

  continuousRec = new SR();
  continuousRec.lang           = window.langAPI ? window.langAPI.getLocale() : 'en-US';
  continuousRec.continuous     = true;
  continuousRec.interimResults = false;

  continuousRec.onresult = e => {
    const last = e.results[e.results.length - 1];
    if (last.isFinal) {
      const text = last[0].transcript.toLowerCase();
      if (voiceEngine.wakeWords.some(w => text.includes(w))) {
        onWakeWordDetected(text);
      }
    }
  };
  continuousRec.onend = () => {
    if (voiceEngine.wakeWordActive) {
      setTimeout(() => continuousRec?.start(), 500);
    }
  };
  continuousRec.onerror = () => {};

  try { continuousRec.start(); appendLog('[VOICE] Continuous wake-word listening active'); }
  catch {}
}

function stopContinuousListening() {
  try { continuousRec?.stop(); } catch {}
  continuousRec = null;
}

// ── Text-to-Speech ────────────────────────────────────────────────────────────
function speakARIA(text, opts = {}) {
  if (!voiceEngine.synthesis) return;

  // Queue if already speaking
  if (voiceEngine.isSpeakBusy) {
    voiceEngine.speakQueue.push({ text, opts });
    return;
  }

  voiceEngine.synthesis.cancel();
  const clean = text.replace(/\*\*/g,'').replace(/\*/g,'').replace(/\n/g,' ').replace(/[#*_`]/g,'').slice(0, 400);
  const utt   = new SpeechSynthesisUtterance(clean);

  const profile = VOICE_PROFILES[opts.profile || 'aria_default'];
  utt.rate   = opts.rate   || voiceEngine.rate;
  utt.pitch  = opts.pitch  || voiceEngine.pitch;
  utt.volume = opts.volume || voiceEngine.volume;

  // Language-aware voice selection
  const langCode = window.langAPI ? window.langAPI.getCurrent() : 'en';
  const locale   = window.langAPI ? window.langAPI.getLocale()  : 'en-US';
  utt.lang = locale;

  const voices = voiceEngine.synthesis.getVoices();

  if (langCode !== 'en') {
    const langPref = locale.split('-')[0];
    utt.voice = voices.find(v => v.lang === locale) ||
                voices.find(v => v.lang.startsWith(langPref)) ||
                voiceEngine.currentVoice;
  } else {
    utt.voice = voiceEngine.currentVoice ||
                voices.find(v => profile.prefer.some(p => v.name.includes(p)));
  }

  utt.onstart = () => {
    voiceEngine.isSpeaking   = true;
    voiceEngine.isSpeakBusy  = true;
    updateVoiceUI('speaking');
  };

  utt.onend = utt.onerror = () => {
    voiceEngine.isSpeaking  = false;
    voiceEngine.isSpeakBusy = false;
    updateVoiceUI('standby');

    // Process queue
    if (voiceEngine.speakQueue.length > 0) {
      const next = voiceEngine.speakQueue.shift();
      setTimeout(() => speakARIA(next.text, next.opts), 200);
    }
  };

  voiceEngine.synthesis.speak(utt);
}

function stopSpeaking() {
  voiceEngine.synthesis?.cancel();
  voiceEngine.isSpeaking  = false;
  voiceEngine.isSpeakBusy = false;
  voiceEngine.speakQueue  = [];
  updateVoiceUI('standby');
}

function adjustVoice(adjustment) {
  switch (adjustment.toLowerCase()) {
    case 'louder':  voiceEngine.volume = Math.min(1.0, voiceEngine.volume + 0.1); break;
    case 'quieter': voiceEngine.volume = Math.max(0.1, voiceEngine.volume - 0.1); break;
    case 'faster':  voiceEngine.rate   = Math.min(1.5, voiceEngine.rate   + 0.1); break;
    case 'slower':  voiceEngine.rate   = Math.max(0.5, voiceEngine.rate   - 0.1); break;
  }
  saveVoicePrefs();
  refreshVoiceControls();
}

// ── Audio Context / Visualization ────────────────────────────────────────────
async function initAudioContext() {
  if (voiceEngine.audioContext) return;
  try {
    voiceEngine.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    voiceEngine.micStream = stream;

    const source   = voiceEngine.audioContext.createMediaStreamSource(stream);
    const analyser = voiceEngine.audioContext.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser);
    voiceEngine.analyserNode = analyser;
    appendLog('[VOICE] Audio context initialized — real waveform active');
  } catch (e) {
    appendLog('[VOICE] Audio context: ' + e.message);
  }
}

let audioVisAnimId = null;
function startAudioVisualization() {
  if (!voiceEngine.analyserNode) return;
  const canvas = document.getElementById('waveform-canvas');
  if (!canvas) return;

  const ctx    = canvas.getContext('2d');
  const W      = canvas.width;
  const H      = canvas.height;
  const buf    = new Uint8Array(voiceEngine.analyserNode.frequencyBinCount);

  function draw() {
    audioVisAnimId = requestAnimationFrame(draw);
    voiceEngine.analyserNode.getByteFrequencyData(buf);

    ctx.clearRect(0, 0, W, H);
    const barW = W / buf.length * 2.5;

    buf.forEach((val, i) => {
      const h = (val / 255) * H;
      const x = i * barW;
      const hue = 180 + (val / 255) * 60;
      ctx.fillStyle = `hsla(${hue}, 100%, 55%, 0.8)`;
      ctx.fillRect(x, H - h, barW - 1, h);
    });
  }
  draw();
}

function stopAudioVisualization() {
  if (audioVisAnimId) { cancelAnimationFrame(audioVisAnimId); audioVisAnimId = null; }
}

// ── UI ────────────────────────────────────────────────────────────────────────
function updateVoiceUI(state) {
  const btn    = document.getElementById('voice-btn');
  const label  = document.getElementById('voice-status-label');
  const dot    = document.getElementById('dot-voice');
  const strings = window.langAPI ? window.langAPI.getUIStrings(window.langAPI.getCurrent()) : {};

  const STATES = {
    listening: {
      btn:   { class: 'recording', text: '⏹', title: 'Stop listening' },
      label: strings.listening || '🎙 LISTENING...',
      dot:   { bg: '#ff4444', shadow: '0 0 8px #ff4444' },
      wave:  true,
    },
    speaking: {
      btn:   { class: '',  text: '🎙', title: 'Voice input' },
      label: strings.speaking || '🔊 ARIA SPEAKING',
      dot:   { bg: '#00d4ff', shadow: '0 0 8px #00d4ff' },
      wave:  true,
    },
    standby: {
      btn:   { class: '',  text: '🎙', title: 'Voice input' },
      label: strings.standby || 'STANDBY',
      dot:   { bg: '#4a7a99', shadow: 'none' },
      wave:  false,
    },
    processing: {
      btn:   { class: '',  text: '🎙', title: 'Voice input' },
      label: strings.processing || '◈ PROCESSING...',
      dot:   { bg: '#9b59ff', shadow: '0 0 8px #9b59ff' },
      wave:  true,
    },
  };

  const s = STATES[state] || STATES.standby;
  if (btn) {
    btn.classList.toggle('recording', s.btn.class === 'recording');
    btn.textContent = s.btn.text;
    btn.title       = s.btn.title;
  }
  if (label) label.textContent = s.label;
  if (dot)   { dot.style.background = s.dot.bg; dot.style.boxShadow = s.dot.shadow; }
  if (typeof setWaveActive === 'function') setWaveActive(s.wave);
}

function updateVoiceStatus(msg) {
  const label = document.getElementById('voice-status-label');
  if (label) label.textContent = msg;
}

// ── Voice Panel Builder ────────────────────────────────────────────────────────
function buildVoicePanel() {
  injectVoiceView();
}

function injectVoiceView() {
  const viewContainer = document.getElementById('view-container');
  if (!viewContainer || document.getElementById('view-voice')) return;

  const view = document.createElement('div');
  view.id        = 'view-voice';
  view.className = 'view';
  view.innerHTML = `
    <div class="view-header">VOICE ENGINE — ADVANCED SPEECH CONTROL CENTER</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;padding:14px;overflow-y:auto;flex:1;">

      <!-- Live Input Panel -->
      <div style="background:var(--bg2);border:1px solid var(--cyan3);border-radius:4px;padding:12px;display:flex;flex-direction:column;gap:10px;">
        <div class="panel-title">LIVE VOICE INPUT</div>

        <!-- Big mic button -->
        <div style="display:flex;flex-direction:column;align-items:center;gap:10px;">
          <button id="big-mic-btn" onclick="toggleVoiceEngineListening()"
            style="width:80px;height:80px;border-radius:50%;background:rgba(0,212,255,0.08);border:2px solid var(--cyan3);color:var(--cyan);font-size:28px;cursor:pointer;transition:all 0.3s;display:flex;align-items:center;justify-content:center;">
            🎙
          </button>
          <div id="voice-confidence" style="font-family:var(--mono);font-size:9px;color:var(--text3);">CONFIDENCE: —</div>
          <div id="live-transcript" style="width:100%;min-height:60px;background:rgba(0,0,0,0.3);border:1px solid rgba(0,212,255,0.15);border-radius:3px;padding:8px;font-family:var(--mono);font-size:10px;color:var(--text2);line-height:1.5;"></div>
        </div>

        <!-- Wake word -->
        <div style="display:flex;align-items:center;gap:8px;">
          <button id="wake-word-btn" onclick="toggleWakeWord()"
            style="flex:1;background:rgba(0,0,0,0.3);border:1px solid var(--cyan3);color:var(--text3);padding:7px;font-family:var(--mono);font-size:9px;border-radius:3px;cursor:pointer;letter-spacing:1px;transition:all 0.2s;">
            ⚪ WAKE: OFF
          </button>
          <button onclick="stopSpeaking()"
            style="flex:1;background:rgba(255,68,68,0.08);border:1px solid rgba(255,68,68,0.3);color:var(--red);padding:7px;font-family:var(--mono);font-size:9px;border-radius:3px;cursor:pointer;letter-spacing:1px;">
            ⏹ STOP
          </button>
        </div>

        <div class="panel-title" style="margin-top:4px;">VOICE COMMANDS</div>
        <div style="font-family:var(--mono);font-size:9px;color:var(--text3);line-height:2;">
          <div>"Hey ARIA, open settings"</div>
          <div>"Hey ARIA, clear chat"</div>
          <div>"Hey ARIA, set mode research"</div>
          <div>"Hey ARIA, self-update"</div>
          <div>"Hey ARIA, speak louder/quieter"</div>
          <div>"Hey ARIA, switch language fr"</div>
          <div>"Hey ARIA, open vision"</div>
          <div>"Hey ARIA, stop speaking"</div>
        </div>
      </div>

      <!-- Voice Settings -->
      <div style="background:var(--bg2);border:1px solid var(--cyan3);border-radius:4px;padding:12px;display:flex;flex-direction:column;gap:10px;">
        <div class="panel-title">VOICE PROFILE & SETTINGS</div>

        <div style="font-family:var(--mono);font-size:9px;color:var(--text3);margin-bottom:2px;">ACTIVE PROFILE</div>
        <div id="voice-profile-list" style="display:flex;flex-direction:column;gap:4px;"></div>

        <div class="panel-title" style="margin-top:6px;">ADJUSTMENTS</div>
        <div style="display:flex;flex-direction:column;gap:8px;" id="voice-controls">
          <div>
            <div style="display:flex;justify-content:space-between;font-family:var(--mono);font-size:9px;color:var(--text3);margin-bottom:3px;">
              <span>VOLUME</span><span id="vol-val">${Math.round(voiceEngine.volume * 100)}%</span>
            </div>
            <input type="range" min="0" max="100" value="${Math.round(voiceEngine.volume*100)}" id="vol-slider"
              oninput="voiceEngine.volume=this.value/100;document.getElementById('vol-val').textContent=this.value+'%';saveVoicePrefs()"
              style="width:100%;accent-color:var(--cyan);cursor:pointer;">
          </div>
          <div>
            <div style="display:flex;justify-content:space-between;font-family:var(--mono);font-size:9px;color:var(--text3);margin-bottom:3px;">
              <span>RATE</span><span id="rate-val">${voiceEngine.rate.toFixed(2)}x</span>
            </div>
            <input type="range" min="50" max="150" value="${Math.round(voiceEngine.rate*100)}" id="rate-slider"
              oninput="voiceEngine.rate=this.value/100;document.getElementById('rate-val').textContent=(this.value/100).toFixed(2)+'x';saveVoicePrefs()"
              style="width:100%;accent-color:var(--cyan);cursor:pointer;">
          </div>
          <div>
            <div style="display:flex;justify-content:space-between;font-family:var(--mono);font-size:9px;color:var(--text3);margin-bottom:3px;">
              <span>PITCH</span><span id="pitch-val">${voiceEngine.pitch.toFixed(2)}</span>
            </div>
            <input type="range" min="50" max="200" value="${Math.round(voiceEngine.pitch*100)}" id="pitch-slider"
              oninput="voiceEngine.pitch=this.value/100;document.getElementById('pitch-val').textContent=(this.value/100).toFixed(2);saveVoicePrefs()"
              style="width:100%;accent-color:var(--cyan);cursor:pointer;">
          </div>
        </div>

        <button onclick="testVoice()"
          style="background:rgba(0,212,255,0.1);border:1px solid var(--cyan3);color:var(--cyan);padding:8px;font-family:var(--mono);font-size:10px;border-radius:3px;cursor:pointer;margin-top:4px;letter-spacing:1px;">
          ▶ TEST VOICE
        </button>

        <div class="panel-title" style="margin-top:6px;">AVAILABLE SYSTEM VOICES</div>
        <div id="sys-voice-list" style="overflow-y:auto;max-height:120px;font-family:var(--mono);font-size:9px;display:flex;flex-direction:column;gap:3px;"></div>
      </div>

      <!-- Command History & Stats -->
      <div style="background:var(--bg2);border:1px solid var(--cyan3);border-radius:4px;padding:12px;display:flex;flex-direction:column;gap:10px;">
        <div class="panel-title">COMMAND HISTORY</div>
        <div id="cmd-history" style="overflow-y:auto;max-height:180px;display:flex;flex-direction:column;gap:4px;"></div>

        <div class="panel-title" style="margin-top:6px;">VOICE STATS</div>
        <div id="voice-stats" style="font-family:var(--mono);font-size:10px;color:var(--text2);line-height:2;"></div>

        <div class="panel-title" style="margin-top:6px;">RECOGNITION TEST</div>
        <textarea id="tts-test-input" placeholder="Type text for ARIA to speak..."
          style="width:100%;height:60px;background:rgba(0,0,0,0.4);border:1px solid var(--cyan3);color:var(--text);padding:6px;font-family:var(--mono);font-size:11px;border-radius:3px;outline:none;resize:none;"></textarea>
        <div style="display:flex;gap:6px;">
          <button onclick="speakARIA(document.getElementById('tts-test-input').value)"
            style="flex:1;background:rgba(0,212,255,0.1);border:1px solid var(--cyan3);color:var(--cyan);padding:6px;font-family:var(--mono);font-size:9px;border-radius:3px;cursor:pointer;">▶ SPEAK</button>
          <button onclick="stopSpeaking()"
            style="flex:1;background:rgba(255,68,68,0.08);border:1px solid rgba(255,68,68,0.3);color:var(--red);padding:6px;font-family:var(--mono);font-size:9px;border-radius:3px;cursor:pointer;">⏹ STOP</button>
        </div>
      </div>
    </div>
  `;

  viewContainer.appendChild(view);

  // Add Voice button to title bar
  const tbRight = document.querySelector('.tb-right');
  if (tbRight && !document.getElementById('btn-view-voice')) {
    const btn = document.createElement('button');
    btn.id        = 'btn-view-voice';
    btn.className = 'tb-btn';
    btn.textContent = '🎙';
    btn.title     = 'Voice Engine';
    btn.onclick   = () => switchView('voice');
    tbRight.insertBefore(btn, tbRight.querySelector('.tb-sep'));
  }

  renderVoiceProfiles();
  renderSystemVoices();
  updateVoiceStats();
}

function toggleVoiceEngineListening() {
  if (voiceEngine.isListening) {
    stopListening();
    const btn = document.getElementById('big-mic-btn');
    if (btn) { btn.style.background = 'rgba(0,212,255,0.08)'; btn.style.borderColor = 'var(--cyan3)'; btn.style.color = 'var(--cyan)'; }
  } else {
    initAudioContext().then(() => startListening());
    const btn = document.getElementById('big-mic-btn');
    if (btn) { btn.style.background = 'rgba(255,68,68,0.2)'; btn.style.borderColor = 'var(--red)'; btn.style.color = 'var(--red)'; }
  }
}

function renderVoiceProfiles() {
  const el = document.getElementById('voice-profile-list');
  if (!el) return;
  el.innerHTML = Object.entries(VOICE_PROFILES).map(([key, p]) => {
    const voice   = voiceEngine.voiceProfiles[key];
    const isActive = voiceEngine.currentVoice === voice;
    return `<div onclick="selectVoiceProfile('${key}')"
      style="display:flex;align-items:center;gap:8px;padding:5px 8px;border-radius:3px;cursor:pointer;border:1px solid ${isActive ? 'var(--cyan)' : 'rgba(0,212,255,0.15)'};background:${isActive ? 'rgba(0,212,255,0.1)' : 'rgba(0,0,0,0.2)'};transition:all 0.2s;"
      onmouseover="this.style.background='rgba(0,212,255,0.12)'" onmouseout="this.style.background='${isActive ? 'rgba(0,212,255,0.1)' : 'rgba(0,0,0,0.2)'}'">
      <span style="font-size:14px;">${isActive ? '🔊' : '🔈'}</span>
      <div>
        <div style="font-family:var(--mono);font-size:9px;color:${isActive ? 'var(--cyan)' : 'var(--text2)'};">${p.name}</div>
        <div style="font-family:var(--mono);font-size:8px;color:var(--text3);">${voice ? voice.name.slice(0,22) : 'No matching voice'}</div>
      </div>
    </div>`;
  }).join('');
}

function selectVoiceProfile(key) {
  const voice = voiceEngine.voiceProfiles[key];
  if (voice) {
    voiceEngine.currentVoice = voice;
    const p = VOICE_PROFILES[key];
    voiceEngine.rate  = p.rate;
    voiceEngine.pitch = p.pitch;
    voiceEngine.volume = p.volume;
    refreshVoiceControls();
    renderVoiceProfiles();
    speakARIA(`Voice profile changed to ${p.name}.`);
    saveVoicePrefs();
    appendLog(`[VOICE] Profile: ${p.name}`);
  }
}

function refreshVoiceControls() {
  const volS  = document.getElementById('vol-slider');
  const rateS = document.getElementById('rate-slider');
  const pitchS= document.getElementById('pitch-slider');
  const volV  = document.getElementById('vol-val');
  const rateV = document.getElementById('rate-val');
  const pitchV= document.getElementById('pitch-val');
  if (volS)  { volS.value  = Math.round(voiceEngine.volume * 100); if (volV)  volV.textContent  = volS.value + '%'; }
  if (rateS) { rateS.value = Math.round(voiceEngine.rate   * 100); if (rateV)  rateV.textContent = (voiceEngine.rate).toFixed(2) + 'x'; }
  if (pitchS){ pitchS.value= Math.round(voiceEngine.pitch  * 100); if (pitchV) pitchV.textContent= voiceEngine.pitch.toFixed(2); }
}

function renderSystemVoices() {
  const el = document.getElementById('sys-voice-list');
  if (!el) return;
  const voices = voiceEngine.synthesis?.getVoices() || [];
  el.innerHTML = voices.slice(0, 20).map(v => `
    <div onclick="voiceEngine.currentVoice=speechSynthesis.getVoices().find(x=>x.name==='${v.name.replace(/'/g,'')}')"
      style="padding:3px 5px;border-radius:2px;cursor:pointer;border:1px solid transparent;transition:all 0.15s;"
      onmouseover="this.style.background='rgba(0,212,255,0.08)';this.style.borderColor='rgba(0,212,255,0.2)'"
      onmouseout="this.style.background='transparent';this.style.borderColor='transparent'">
      <span style="color:var(--text2);">${v.name.slice(0,28)}</span>
      <span style="color:var(--text3);margin-left:4px;">${v.lang}</span>
    </div>
  `).join('');
}

function refreshCommandHistory() {
  const el = document.getElementById('cmd-history');
  if (!el) return;
  el.innerHTML = voiceEngine.commandHistory.slice(0, 8).map(c => `
    <div style="background:rgba(0,0,0,0.3);border:1px solid rgba(0,212,255,0.1);border-left:2px solid var(--purple);padding:4px 7px;border-radius:2px;font-family:var(--mono);font-size:9px;color:var(--text3);">
      ${c.text.slice(0, 55)}${c.text.length > 55 ? '…' : ''}
    </div>
  `).join('');

  const confEl = document.getElementById('voice-confidence');
  if (confEl) confEl.textContent = `CONFIDENCE: ${voiceEngine.confidence ? (voiceEngine.confidence * 100).toFixed(0) + '%' : '—'}`;

  updateVoiceStats();
}

function updateVoiceStats() {
  const el = document.getElementById('voice-stats');
  if (!el) return;
  el.innerHTML = `
    <div>Commands issued: <span style="color:var(--cyan)">${voiceEngine.commandHistory.length}</span></div>
    <div>Wake word: <span style="color:${voiceEngine.wakeWordActive ? 'var(--green)' : 'var(--text3)'}">${voiceEngine.wakeWordActive ? 'ACTIVE' : 'OFF'}</span></div>
    <div>Volume: <span style="color:var(--cyan)">${Math.round(voiceEngine.volume * 100)}%</span></div>
    <div>Rate: <span style="color:var(--cyan)">${voiceEngine.rate.toFixed(2)}x</span></div>
    <div>Language: <span style="color:var(--cyan)">${voiceEngine.language}</span></div>
    <div>Queue: <span style="color:var(--cyan)">${voiceEngine.speakQueue.length}</span></div>
  `;
}

function testVoice() {
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  speakARIA(`${greet}. This is ARIA speaking. Voice systems are fully operational. All parameters are within normal range.`);
}

function saveVoicePrefs() {
  try {
    localStorage.setItem('aria-voice', JSON.stringify({
      volume: voiceEngine.volume,
      rate:   voiceEngine.rate,
      pitch:  voiceEngine.pitch,
      wakeWordActive: voiceEngine.wakeWordActive,
    }));
  } catch {}
}

// ── Override main app toggleVoice ─────────────────────────────────────────────
// Replaces the basic version in app.js
window.toggleVoice = function() {
  if (voiceEngine.isListening) stopListening();
  else { initAudioContext().catch(() => {}); startListening(); }
};

// Override speak() with advanced version
window.speak = function(text) {
  if (typeof state !== 'undefined' && !state.voiceEnabled) return;
  speakARIA(text);
};

// ── Boot ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(initVoiceEngine, 2000);
});
