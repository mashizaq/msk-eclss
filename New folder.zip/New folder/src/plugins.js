/**
 * ARIA Desktop — Plugin & Skills System
 * Extensible module loader: custom skills, integrations, tools, marketplace
 */

'use strict';

// ── Plugin Registry ───────────────────────────────────────────────────────────
const pluginSystem = {
  registry:   {},
  active:     {},
  hooks:      { onMessage:[], onSend:[], onUpdate:[], onModeChange:[], onLangChange:[] },
  skillStore: [],
};

// ── Built-in Skills (ARIA Core Plugins) ───────────────────────────────────────
const BUILT_IN_SKILLS = [

  {
    id: 'skill_calculator',
    name: 'Calculator',
    icon: '🧮',
    version: '1.0',
    description: 'Evaluate mathematical expressions directly from chat',
    category: 'utility',
    active: true,
    trigger: /^(calc|calculate|compute|math|=)\s+(.+)/i,
    handler(match) {
      try {
        const expr = match[2].replace(/[^0-9+\-*/().%^ ]/g, '');
        const result = Function(`"use strict"; return (${expr})`)();
        return `🧮 **Calculator**\n\`${match[2]}\` = **${result}**`;
      } catch {
        return `🧮 Could not evaluate: \`${match[2]}\``;
      }
    }
  },

  {
    id: 'skill_timer',
    name: 'Timer',
    icon: '⏱',
    version: '1.0',
    description: 'Set countdown timers with voice alert',
    category: 'assistant',
    active: true,
    trigger: /^(set )?timer (?:for )?(\d+)\s*(minute|min|second|sec|hour|hr)s?/i,
    handler(match) {
      const amount = parseInt(match[2]);
      const unit   = match[3].toLowerCase();
      let ms = amount * (unit.startsWith('sec') ? 1000 : unit.startsWith('hour') || unit.startsWith('hr') ? 3600000 : 60000);
      const label  = `${amount} ${unit}${amount !== 1 ? 's' : ''}`;
      const endTime = new Date(Date.now() + ms);

      setTimeout(() => {
        speakARIA(`Timer complete! Your ${label} timer has finished.`);
        if (typeof notify === 'function') notify(`⏱ Timer done: ${label}`);
        if (typeof addMessage === 'function') addMessage('aria', `⏱ **Timer Complete!**\nYour **${label}** timer has finished.`);
      }, ms);

      startTimerDisplay(label, ms);
      return `⏱ **Timer set for ${label}**\nI'll alert you at ${endTime.toLocaleTimeString()}.`;
    }
  },

  {
    id: 'skill_notes',
    name: 'Quick Notes',
    icon: '📝',
    version: '1.0',
    description: 'Create and retrieve quick notes',
    category: 'productivity',
    active: true,
    notes: JSON.parse(localStorage.getItem('aria-notes') || '[]'),
    trigger: /^(note|remember|save note|add note):?\s+(.+)/i,
    handler(match) {
      const note = { text: match[2], time: new Date().toISOString(), id: Date.now() };
      this.notes.push(note);
      localStorage.setItem('aria-notes', JSON.stringify(this.notes.slice(-50)));
      return `📝 **Note saved!**\n"${match[2]}"\n\nYou have ${this.notes.length} notes. Say "show notes" to list them.`;
    }
  },

  {
    id: 'skill_notes_list',
    name: 'Show Notes',
    icon: '📋',
    version: '1.0',
    description: 'List saved notes',
    category: 'productivity',
    active: true,
    trigger: /^(show|list|read) (my )?notes?/i,
    handler() {
      const skill = pluginSystem.registry['skill_notes'];
      const notes = skill ? skill.notes : JSON.parse(localStorage.getItem('aria-notes') || '[]');
      if (!notes.length) return '📝 No notes saved yet. Say "note: your text" to save one.';
      const list = notes.slice(-5).reverse().map((n, i) =>
        `${i + 1}. ${n.text} *(${new Date(n.time).toLocaleDateString()})*`
      ).join('\n');
      return `📋 **Your Notes** (last 5):\n${list}`;
    }
  },

  {
    id: 'skill_unit_converter',
    name: 'Unit Converter',
    icon: '📐',
    version: '1.0',
    description: 'Convert between common units',
    category: 'utility',
    active: true,
    trigger: /convert\s+([\d.]+)\s*(\w+)\s+to\s+(\w+)/i,
    handler(match) {
      const val  = parseFloat(match[1]);
      const from = match[2].toLowerCase();
      const to   = match[3].toLowerCase();
      const CONV = {
        km_miles: v => (v * 0.621371).toFixed(4),
        miles_km: v => (v * 1.60934).toFixed(4),
        kg_lbs:   v => (v * 2.20462).toFixed(4),
        lbs_kg:   v => (v * 0.453592).toFixed(4),
        c_f:      v => (v * 9/5 + 32).toFixed(2),
        f_c:      v => ((v - 32) * 5/9).toFixed(2),
        m_ft:     v => (v * 3.28084).toFixed(4),
        ft_m:     v => (v * 0.3048).toFixed(4),
        l_gal:    v => (v * 0.264172).toFixed(4),
        gal_l:    v => (v * 3.78541).toFixed(4),
        cm_in:    v => (v * 0.393701).toFixed(4),
        in_cm:    v => (v * 2.54).toFixed(4),
      };
      const key = `${from}_${to}`;
      if (CONV[key]) {
        return `📐 **${val} ${from}** = **${CONV[key](val)} ${to}**`;
      }
      return `📐 I don't have a converter for ${from} → ${to} yet. I can convert: km↔miles, kg↔lbs, °C↔°F, m↔ft, L↔gal, cm↔in`;
    }
  },

  {
    id: 'skill_weather_brief',
    name: 'Weather Brief',
    icon: '🌤',
    version: '1.0',
    description: 'Weather context with location awareness',
    category: 'information',
    active: true,
    trigger: /^(weather|forecast|temperature|will it rain|is it hot)/i,
    handler() {
      return null; // Let Claude handle weather with its knowledge; just mark intent
    }
  },

  {
    id: 'skill_pomodoro',
    name: 'Pomodoro Timer',
    icon: '🍅',
    version: '1.0',
    description: 'Productivity Pomodoro technique timer',
    category: 'productivity',
    active: true,
    trigger: /^(start |begin )?pomodoro(\s+(\d+))?/i,
    handler(match) {
      const mins = parseInt(match[3] || '25');
      const ms   = mins * 60000;
      setTimeout(() => {
        speakARIA(`Pomodoro complete! Take a 5 minute break. Great work!`);
        if (typeof addMessage === 'function') addMessage('aria', `🍅 **Pomodoro Complete!**\n${mins} minutes of focused work done. Take a 5-minute break. You've earned it!`);
      }, ms);
      startTimerDisplay(`Pomodoro (${mins}m)`, ms);
      return `🍅 **Pomodoro started!**\nFocus timer: **${mins} minutes**\nStay focused — I'll alert you when it's time for a break.`;
    }
  },

  {
    id: 'skill_dictionary',
    name: 'Dictionary',
    icon: '📖',
    version: '1.0',
    description: 'Define words with etymology',
    category: 'knowledge',
    active: true,
    trigger: /^(define|definition of|what (does|is)|meaning of)\s+["']?(\w+)["']?/i,
    handler(match) {
      return null; // Signals Claude to handle with full dictionary knowledge
    }
  },

  {
    id: 'skill_smart_home',
    name: 'Smart Home',
    icon: '🏠',
    version: '1.1',
    description: 'Alexa-style smart home command simulation',
    category: 'home',
    active: true,
    trigger: /^(turn (on|off)|set|dim|brighten|lock|unlock)\s+(?:the\s+)?(.+)/i,
    handler(match) {
      const action = match[1];
      const target = match[3];
      const DEVICES = ['lights','lamp','fan','ac','tv','heater','thermostat','alarm','door','gate'];
      const isKnown = DEVICES.some(d => target.toLowerCase().includes(d));
      if (!isKnown) return null;
      return `🏠 **Smart Home Command**\n"${action} the ${target}" — command sent to home hub.\n\n*(Connect your smart home API in Settings → Integrations to enable real control.)*`;
    }
  },

  {
    id: 'skill_code_runner',
    name: 'Code Snippet',
    icon: '💻',
    version: '1.0',
    description: 'Detect and format code snippets in chat',
    category: 'developer',
    active: true,
    trigger: /^(run|execute|evaluate)\s+(javascript|python|js|py)\s*:\s*(.+)/is,
    handler(match) {
      const lang = match[2].toLowerCase();
      const code = match[3];
      if (lang === 'javascript' || lang === 'js') {
        try {
          const result = Function(`"use strict"; return (${code})`)();
          return `💻 **JavaScript**\n\`\`\`\n${code}\n\`\`\`\n**Output:** \`${result}\``;
        } catch (e) {
          return `💻 **JavaScript Error:** ${e.message}`;
        }
      }
      return `💻 **${lang}** execution requires the Python backend. Send to ARIA for analysis.`;
    }
  },
];

// ── Plugin Loader ─────────────────────────────────────────────────────────────
function loadPlugins() {
  BUILT_IN_SKILLS.forEach(skill => {
    pluginSystem.registry[skill.id] = skill;
    if (skill.active) pluginSystem.active[skill.id] = skill;
  });

  // Load user plugins from localStorage
  try {
    const userPlugins = JSON.parse(localStorage.getItem('aria-plugins') || '[]');
    userPlugins.forEach(p => installPlugin(p));
  } catch {}

  appendLog(`[PLUGIN] ${Object.keys(pluginSystem.active).length} skills loaded`);
}

function installPlugin(plugin) {
  if (!plugin.id || !plugin.handler) return false;
  pluginSystem.registry[plugin.id] = plugin;
  if (plugin.active !== false) pluginSystem.active[plugin.id] = plugin;
  appendLog(`[PLUGIN] Installed: ${plugin.name} v${plugin.version}`);
  return true;
}

function unloadPlugin(id) {
  delete pluginSystem.active[id];
  appendLog(`[PLUGIN] Unloaded: ${id}`);
}

// ── Message Hook — intercept before sending to Claude ─────────────────────────
function runSkillCheck(text) {
  for (const skill of Object.values(pluginSystem.active)) {
    if (!skill.trigger) continue;
    const match = text.match(skill.trigger);
    if (match) {
      const result = skill.handler(match);
      if (result) return { handled: true, reply: result, skill: skill.name };
    }
  }
  return { handled: false };
}

// ── Timer Display ──────────────────────────────────────────────────────────────
function startTimerDisplay(label, ms) {
  let overlay = document.getElementById('timer-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'timer-overlay';
    overlay.style.cssText = `
      position:fixed;bottom:90px;right:20px;
      background:var(--bg2);border:1px solid var(--gold);border-radius:4px;
      padding:10px 14px;font-family:var(--mono);font-size:11px;
      color:var(--gold);z-index:400;box-shadow:0 0 20px rgba(255,215,0,0.2);
      min-width:160px;
    `;
    document.body.appendChild(overlay);
  }

  const end   = Date.now() + ms;
  const timer = setInterval(() => {
    const remaining = Math.max(0, end - Date.now());
    const secs = Math.floor(remaining / 1000);
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    overlay.innerHTML = `⏱ ${label}<br>${m}:${s.toString().padStart(2,'0')} remaining
      <button onclick="this.parentElement.remove()" style="float:right;background:transparent;border:none;color:var(--text3);cursor:pointer;font-size:11px;">✕</button>`;
    if (remaining <= 0) { clearInterval(timer); setTimeout(() => overlay.remove(), 3000); }
  }, 1000);
}

// ── Plugin Marketplace View ───────────────────────────────────────────────────
const MARKETPLACE_PLUGINS = [
  { id:'mkt_weather_live',  name:'Live Weather API',  icon:'🌦', category:'information', description:'Real-time weather via OpenWeatherMap API. Requires API key.', version:'2.0', stars:4.8 },
  { id:'mkt_google_cal',    name:'Google Calendar',   icon:'📅', category:'productivity', description:'Sync ARIA with Google Calendar for event management.', version:'1.5', stars:4.6 },
  { id:'mkt_spotify',       name:'Spotify Control',   icon:'🎵', category:'media',        description:'Control Spotify playback — play, pause, skip, volume.', version:'1.2', stars:4.7 },
  { id:'mkt_news_feed',     name:'News Feed',          icon:'📰', category:'information', description:'Live news headlines from multiple sources.', version:'1.3', stars:4.4 },
  { id:'mkt_notion',        name:'Notion Integration', icon:'📓', category:'productivity', description:'Read and write Notion pages from ARIA chat.', version:'1.0', stars:4.5 },
  { id:'mkt_homeassist',    name:'Home Assistant',     icon:'🏡', category:'home',         description:'Full Home Assistant integration for real smart home control.', version:'2.1', stars:4.9 },
  { id:'mkt_whatsapp',      name:'WhatsApp Messages',  icon:'💬', category:'comms',        description:'Send WhatsApp messages via ARIA voice/chat commands.', version:'1.1', stars:4.3 },
  { id:'mkt_wolfram',       name:'Wolfram Alpha',      icon:'🔢', category:'knowledge',    description:'Deep computational knowledge via Wolfram Alpha API.', version:'1.4', stars:4.8 },
  { id:'mkt_maps',          name:'Maps & Navigation',  icon:'🗺', category:'utility',      description:'Get directions and location info via Google Maps.', version:'1.0', stars:4.5 },
  { id:'mkt_translate_deep',name:'DeepL Translation',  icon:'🌐', category:'language',     description:'Professional-grade translation via DeepL API.', version:'1.2', stars:4.9 },
];

function injectPluginView() {
  const viewContainer = document.getElementById('view-container');
  if (!viewContainer || document.getElementById('view-plugins')) return;

  const view = document.createElement('div');
  view.id = 'view-plugins';
  view.className = 'view';
  view.innerHTML = `
    <div class="view-header">ARIA SKILLS & PLUGIN CENTER</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:14px;overflow-y:auto;flex:1;">

      <!-- Active Skills -->
      <div style="background:var(--bg2);border:1px solid var(--cyan3);border-radius:4px;padding:12px;">
        <div class="panel-title">ACTIVE SKILLS (${BUILT_IN_SKILLS.length} built-in)</div>
        <div style="display:flex;flex-direction:column;gap:5px;max-height:360px;overflow-y:auto;">
          ${BUILT_IN_SKILLS.map(s => `
            <div style="display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:3px;background:rgba(0,0,0,0.25);border:1px solid rgba(0,212,255,0.1);">
              <span style="font-size:18px;">${s.icon}</span>
              <div style="flex:1;">
                <div style="font-family:var(--mono);font-size:10px;color:var(--text);">${s.name}</div>
                <div style="font-family:var(--mono);font-size:8px;color:var(--text3);">${s.description}</div>
              </div>
              <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px;">
                <span style="font-family:var(--mono);font-size:8px;padding:2px 5px;background:rgba(0,255,136,0.1);border:1px solid rgba(0,255,136,0.2);border-radius:2px;color:var(--green2);">v${s.version}</span>
                <span style="font-family:var(--mono);font-size:8px;color:var(--text3);">${s.category}</span>
              </div>
            </div>
          `).join('')}
        </div>
        <div class="panel-title" style="margin-top:10px;">INSTALL CUSTOM SKILL</div>
        <textarea id="plugin-json" placeholder='{"id":"my_skill","name":"My Skill","icon":"⭐","trigger":"/pattern/i","handler":"(m) => { return \'Result\'; }","description":"What it does","version":"1.0"}' style="width:100%;height:80px;background:rgba(0,0,0,0.4);border:1px solid var(--cyan3);color:var(--text);padding:6px;font-family:var(--mono);font-size:9px;border-radius:3px;outline:none;resize:none;"></textarea>
        <button onclick="installCustomPlugin()" style="margin-top:5px;width:100%;background:rgba(0,212,255,0.1);border:1px solid var(--cyan3);color:var(--cyan);padding:7px;font-family:var(--mono);font-size:9px;border-radius:3px;cursor:pointer;letter-spacing:1px;">INSTALL PLUGIN</button>
      </div>

      <!-- Marketplace -->
      <div style="background:var(--bg2);border:1px solid var(--cyan3);border-radius:4px;padding:12px;">
        <div class="panel-title">PLUGIN MARKETPLACE</div>
        <div style="display:flex;flex-direction:column;gap:5px;max-height:480px;overflow-y:auto;">
          ${MARKETPLACE_PLUGINS.map(p => `
            <div style="display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:3px;background:rgba(0,0,0,0.2);border:1px solid rgba(0,212,255,0.1);">
              <span style="font-size:20px;">${p.icon}</span>
              <div style="flex:1;">
                <div style="font-family:var(--mono);font-size:10px;color:var(--text);">${p.name}</div>
                <div style="font-family:var(--mono);font-size:8px;color:var(--text3);margin-top:2px;">${p.description}</div>
                <div style="margin-top:3px;font-family:var(--mono);font-size:8px;color:var(--gold);">⭐ ${p.stars} · ${p.category}</div>
              </div>
              <button onclick="marketplaceInstall('${p.id}','${p.name}')"
                style="background:rgba(0,255,136,0.08);border:1px solid rgba(0,255,136,0.25);color:var(--green2);padding:4px 8px;font-family:var(--mono);font-size:8px;border-radius:2px;cursor:pointer;white-space:nowrap;">
                + INSTALL
              </button>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;

  viewContainer.appendChild(view);

  // Button in title bar
  const tbRight = document.querySelector('.tb-right');
  if (tbRight && !document.getElementById('btn-view-plugins')) {
    const btn = document.createElement('button');
    btn.id = 'btn-view-plugins';
    btn.className = 'tb-btn';
    btn.textContent = '🔌';
    btn.title = 'Skills & Plugins';
    btn.onclick = () => switchView('plugins');
    tbRight.insertBefore(btn, tbRight.querySelector('.tb-sep'));
  }
}

function installCustomPlugin() {
  const json = document.getElementById('plugin-json')?.value?.trim();
  if (!json) return;
  try {
    const plugin = JSON.parse(json);
    if (typeof plugin.handler === 'string') {
      plugin.handler = new Function('match', `return (${plugin.handler})(match)`);
    }
    if (typeof plugin.trigger === 'string') {
      const m = plugin.trigger.match(/^\/(.+)\/([gimsuy]*)$/);
      if (m) plugin.trigger = new RegExp(m[1], m[2]);
    }
    installPlugin(plugin);
    notify(`✅ Plugin installed: ${plugin.name}`);
    document.getElementById('plugin-json').value = '';
  } catch (e) {
    notify(`❌ Plugin error: ${e.message}`);
  }
}

function marketplaceInstall(id, name) {
  notify(`📦 "${name}" — configure API key in Settings to activate`);
  appendLog(`[PLUGIN] Marketplace: ${name} marked for installation`);
}

// ── Patch sendMsg to run skill check first ─────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    loadPlugins();
    injectPluginView();

    // Patch the send function
    const _origSendMsg = window.sendMsg;
    window.sendMsg = async function() {
      const input = document.getElementById('msg-input');
      const text  = input?.value?.trim();
      if (!text) return;

      const skillResult = runSkillCheck(text);
      if (skillResult.handled) {
        input.value = '';
        if (typeof autoResize === 'function') autoResize(input);
        if (typeof addMessage === 'function') {
          addMessage('user', text);
          addMessage('aria', skillResult.reply);
          appendLog(`[SKILL] Handled by: ${skillResult.skill}`);
        }
        return;
      }

      return _origSendMsg.call(this);
    };

    appendLog('[PLUGIN] Skill intercept hook active');
  }, 2500);
});
