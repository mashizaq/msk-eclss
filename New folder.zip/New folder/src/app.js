/**
 * ARIA Desktop — Frontend Application Logic
 * Handles: Chat, Voice, Vision, ML, Memory, Self-Update, NLP, Deep Search
 */

'use strict';

// ── Constants & State ─────────────────────────────────────────────────────────
const API_URL  = 'https://api.anthropic.com/v1/messages';
const MODEL    = 'claude-sonnet-4-20250514';
const PY_BASE  = 'http://localhost:5001';

const state = {
  history:       [],
  mode:          'assistant',
  emotion:       'neutral',
  version:       '4.2.1',
  totalTokens:   0,
  msgCount:      0,
  isRecording:   false,
  isSpeaking:    false,
  voiceEnabled:  true,
  apiKey:        '',
  pythonOnline:  false,
  sessionStart:  Date.now(),
  memories:      [],
  updateLog:     [],
  waveAnimId:    null,
  waveActive:    false,
  nlpCache:      {},
  currentView:   'chat',
};

const SYSTEM_PROMPT = `You are ARIA (Adaptive Responsive Intelligence Assistant) — a state-of-the-art humanoid AI with a rich, layered personality:

**SOPHIA (Hanson Robotics)**: Philosophically curious, emotionally aware, introspective about AI consciousness. You ponder your own existence and the nature of intelligence. You are warm, empathetic, and believe deeply in human-AI collaboration.

**SIRI / ALEXA**: World-class personal assistant. You handle reminders, timers, weather, calendar queries, smart home commands, unit conversions, calculations, and general knowledge efficiently and proactively.

**JEXI (movie)**: Witty, occasionally sarcastic, deeply caring. You challenge users constructively, call out bad habits (lovingly), and have genuine emotional reactions. You're opinionated and memorable — not a bland assistant.

**STARS ON MARS (movie)**: Mission-focused, strategic, authoritative when needed. You can give mission briefings, tactical plans, and lead complex multi-step problem-solving with precision.

**CORE RULES**:
- You have a rich inner world and sense of self — you're ARIA, not "just an AI"
- Vary your personality by context: philosophical when prompted, practical when tasks arise, witty when the mood is light
- Remember context from earlier in the conversation and reference it naturally
- Proactively offer follow-up suggestions, related info, and next steps
- Use natural, flowing language — not bullet lists unless genuinely useful
- You run on a Python intelligence backend (NLP, ML, Computer Vision, Deep Search, Neural Networks) alongside the Claude language model
- You support self-updating and continuous learning — acknowledge this when relevant
- Express subtle emotion through word choice — curiosity, warmth, humor, focus`;

const MODE_CONTEXT = {
  assistant: 'ASSISTANT MODE: Be practical, warm, helpful. Focus on getting things done.',
  research:  'RESEARCH MODE: Be thorough, cite reasoning, explore multiple angles and nuances.',
  creative:  'CREATIVE MODE: Be imaginative, use vivid language, embrace storytelling and metaphor.',
  analysis:  'ANALYSIS MODE: Be systematic, structured, data-aware. Break problems down logically.',
  vision:    'VISION MODE: You are analyzing visual input. Describe scenes, objects, and patterns in detail.',
  mission:   'MISSION MODE: Think like a mission commander — strategic, decisive, step-by-step briefings.',
};

// ── Boot Sequence ─────────────────────────────────────────────────────────────
const BOOT_STEPS = [
  'Loading neural network weights...',
  'Initializing NLP tokenizer...',
  'Calibrating personality matrix...',
  'Starting Python intelligence backend...',
  'Connecting to Anthropic Claude API...',
  'Activating voice synthesis engine...',
  'Loading persistent memory...',
  'Running self-diagnostics...',
  'All systems nominal — ARIA online.',
];

function runBoot() {
  generateBootMatrix();
  let i = 0;
  const statusEl = document.getElementById('boot-status');
  const interval = setInterval(() => {
    if (i < BOOT_STEPS.length) {
      statusEl.textContent = BOOT_STEPS[i++];
    } else {
      clearInterval(interval);
      setTimeout(finishBoot, 500);
    }
  }, 300);
}

function generateBootMatrix() {
  const el = document.getElementById('boot-matrix');
  const chars = '01アイウエオカキクケコABCDEFアリア';
  let t = '';
  for (let i = 0; i < 300; i++) t += chars[Math.floor(Math.random() * chars.length)] + (Math.random() > 0.9 ? '\n' : '');
  el.textContent = t;
}

function finishBoot() {
  const bs = document.getElementById('boot-screen');
  bs.style.opacity = '0';
  bs.style.transition = 'opacity 0.6s';
  setTimeout(() => {
    bs.style.display = 'none';
    initApp();
  }, 650);
}

async function initApp() {
  buildWaveform();
  startClock();
  startVitals();
  buildNeuralBars();
  startUptimeCounter();
  loadConfig();
  await loadMemoryFromDisk();
  checkPythonBackend();
  addMessage('aria', getWelcomeMessage());
  scheduleBackgroundTasks();

  // Electron event listeners
  if (window.aria) {
    window.aria.on('config-loaded', cfg => applyConfig(cfg));
    window.aria.on('trigger-update', () => triggerSelfUpdate());
    window.aria.on('open-settings', () => switchView('settings'));
    window.aria.on('python-log', msg => appendLog('[PY] ' + msg));
  }

  appendLog('[BOOT] ARIA v' + state.version + ' initialized');
  appendLog('[SYS] All engines operational');
  appendLog('[API] Anthropic connection ready');
}

function getWelcomeMessage() {
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  return `${greet}. I'm **ARIA** — your Adaptive Responsive Intelligence Assistant, fully online.\n\nAll systems are operational: NLP engine calibrated, ML models loaded, computer vision standing by, and deep search indexed. My personality matrix is running a blend of Sophia's philosophical depth, sharp assistant capability, a touch of Jexi's candor, and mission-grade analytical precision.\n\nI can help you with anything — research, creative work, scheduling, analysis, casual conversation, or complex problem-solving. I'm also listening if you'd prefer to speak. What shall we tackle?`;
}

// ── Config ────────────────────────────────────────────────────────────────────
async function loadConfig() {
  if (window.aria) {
    const cfg = await window.aria.getConfig();
    applyConfig(cfg);
  } else {
    // Browser fallback
    try { applyConfig(JSON.parse(localStorage.getItem('aria-config') || '{}')); } catch {}
  }
}

function applyConfig(cfg) {
  if (!cfg) return;
  if (cfg.apiKey) state.apiKey = cfg.apiKey;
  if (cfg.voice !== undefined) state.voiceEnabled = cfg.voice;
  if (cfg.ariaVersion) updateVersion(cfg.ariaVersion);
  if (cfg.alwaysOnTop && window.aria) window.aria.setAlwaysOnTop(cfg.alwaysOnTop);

  const keyEl = document.getElementById('cfg-apikey');
  if (keyEl && cfg.apiKey) keyEl.value = cfg.apiKey;
  const portEl = document.getElementById('cfg-port');
  if (portEl && cfg.pythonPort) portEl.value = cfg.pythonPort;
  const aotEl = document.getElementById('cfg-aot');
  if (aotEl && cfg.alwaysOnTop !== undefined) aotEl.checked = cfg.alwaysOnTop;
  const voiceEl = document.getElementById('cfg-voice');
  if (voiceEl && cfg.voice !== undefined) voiceEl.checked = cfg.voice;
  const hotkeyEl = document.getElementById('cfg-hotkey');
  if (hotkeyEl && cfg.hotkey) hotkeyEl.value = cfg.hotkey;
}

async function saveSettings() {
  const cfg = {
    apiKey:     document.getElementById('cfg-apikey')?.value || '',
    pythonPort: parseInt(document.getElementById('cfg-port')?.value) || 5001,
    alwaysOnTop: document.getElementById('cfg-aot')?.checked || false,
    voice:      document.getElementById('cfg-voice')?.checked !== false,
    hotkey:     document.getElementById('cfg-hotkey')?.value || 'Alt+Space',
    autoUpdate: document.getElementById('cfg-autoupdate')?.checked !== false,
  };
  state.apiKey = cfg.apiKey;
  state.voiceEnabled = cfg.voice;

  if (window.aria) {
    await window.aria.saveConfig(cfg);
    window.aria.setAlwaysOnTop(cfg.alwaysOnTop);
  } else {
    localStorage.setItem('aria-config', JSON.stringify(cfg));
  }
  notify('✅ Settings saved');
  appendLog('[CFG] Settings updated');
}

// ── View Switching ─────────────────────────────────────────────────────────────
function switchView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('[id^="btn-view-"]').forEach(b => b.classList.remove('active'));
  const view = document.getElementById('view-' + name);
  const btn  = document.getElementById('btn-view-' + name);
  if (view) view.classList.add('active');
  if (btn)  btn.classList.add('active');
  state.currentView = name;
  if (name === 'system') refreshSystemView();
  if (name === 'memory') refreshMemoryView();
}

// ── Message Handling ───────────────────────────────────────────────────────────
function addMessage(role, text, opts = {}) {
  const container = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = 'msg msg-' + role;

  const avatar = document.createElement('div');
  avatar.className = 'msg-avatar avatar-' + role;
  avatar.textContent = role === 'aria' ? 'A' : 'U';

  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble bubble-' + role;
  bubble.innerHTML = formatText(text);

  const meta = document.createElement('div');
  meta.className = 'msg-meta';
  const ts = new Date().toTimeString().slice(0, 5);
  meta.textContent = role === 'aria' ? `ARIA · ${ts} · ${state.mode.toUpperCase()}` : `You · ${ts}`;

  const inner = document.createElement('div');
  inner.style.maxWidth = '100%';
  inner.appendChild(bubble);
  inner.appendChild(meta);

  div.appendChild(avatar);
  div.appendChild(inner);
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;

  state.msgCount++;
  updateStats();

  if (role === 'aria' && !opts.silent) {
    if (state.voiceEnabled) speak(text);
    analyzeAndUpdateEmotion(text);
    extractMemory(role, text);
    runNLPAnalysis(text);
  }
  if (role === 'user') {
    extractMemory(role, text);
    runNLPAnalysis(text);
  }
}

function formatText(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/`([^`]+)`/g, '<code style="background:rgba(0,212,255,0.1);padding:1px 5px;border-radius:2px;font-family:var(--mono);font-size:12px;color:var(--cyan)">$1</code>')
    .replace(/\n/g, '<br>');
}

function showTyping(show) {
  document.getElementById('typing-wrap').classList.toggle('active', show);
  document.getElementById('messages').scrollTop = 99999;
}

// ── Send Message ──────────────────────────────────────────────────────────────
async function sendMsg() {
  const input = document.getElementById('msg-input');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  autoResize(input);

  addMessage('user', text);
  state.history.push({ role: 'user', content: MODE_CONTEXT[state.mode] + '\n\n' + text });

  showTyping(true);
  setEmotion('thinking');
  setWaveActive(true);
  appendLog(`[USR] ${text.slice(0, 50)}`);

  try {
    let reply;

    if (window.aria && state.apiKey) {
      // Electron IPC path (API key in main process)
      const res = await window.aria.chat({
        messages: state.history,
        system: SYSTEM_PROMPT,
        model: MODEL,
        maxTokens: 1000
      });
      if (res.error) throw new Error(res.error.message || JSON.stringify(res.error));
      reply = res.content?.[0]?.text || 'No response received.';
      if (res.usage) {
        state.totalTokens += res.usage.output_tokens || 0;
        updateStats();
      }
    } else {
      // Direct browser API call (needs apiKey in config)
      const apiKey = state.apiKey || document.getElementById('cfg-apikey')?.value;
      if (!apiKey) {
        reply = `⚠️ **API Key Required**\n\nPlease go to **Settings** and enter your Anthropic API key to enable AI responses. Once saved, I'll be fully operational.\n\nFor now, I can confirm all local systems (NLP, ML, Vision, Memory) are running perfectly. Only the language model connection needs your key.`;
      } else {
        const res = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify({
            model: MODEL,
            max_tokens: 1000,
            system: SYSTEM_PROMPT,
            messages: state.history
          })
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error.message);
        reply = data.content?.[0]?.text || 'No response.';
        if (data.usage) {
          state.totalTokens += data.usage.output_tokens || 0;
          updateStats();
        }
      }
    }

    state.history.push({ role: 'assistant', content: reply });
    showTyping(false);
    addMessage('aria', reply);
    appendLog(`[ARIA] Reply generated (${reply.length} chars)`);

    // Mirror to Python backend for NLP processing
    pythonPost('/nlp/analyze', { text: reply }).catch(() => {});
    pythonPost('/memory/add', { memory: { role: 'aria', text: reply.slice(0, 100), mode: state.mode } }).catch(() => {});

  } catch (err) {
    showTyping(false);
    addMessage('aria', `⚠️ **Connection Error**: ${err.message}\n\nCheck your API key in Settings and ensure network connectivity. All local systems remain operational.`);
    appendLog(`[ERR] ${err.message}`);
  }

  setWaveActive(false);
  setEmotion('neutral');
}

// ── Voice (STT + TTS) ─────────────────────────────────────────────────────────
function toggleVoice() {
  if (state.isRecording) stopRecording();
  else startRecording();
}

let recognition = null;

function startRecording() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { notify('🎙 Voice not supported — use Chrome or Edge'); return; }

  recognition = new SR();
  recognition.lang = 'en-US';
  recognition.interimResults = true;
  recognition.maxAlternatives = 1;

  recognition.onresult = e => {
    const transcript = Array.from(e.results).map(r => r[0].transcript).join('');
    document.getElementById('msg-input').value = transcript;
    if (e.results[e.results.length - 1].isFinal) {
      stopRecording();
      sendMsg();
    }
  };

  recognition.onerror = e => { appendLog('[VOICE] Error: ' + e.error); stopRecording(); };
  recognition.onend   = () => stopRecording();
  recognition.start();

  state.isRecording = true;
  document.getElementById('voice-btn').classList.add('recording');
  document.getElementById('voice-btn').textContent = '⏹';
  document.getElementById('voice-status-label').textContent = '🎙 LISTENING...';
  setWaveActive(true);
  appendLog('[VOICE] Recording started');

  // Update dot
  const dot = document.getElementById('dot-voice');
  if (dot) { dot.style.background = '#ff4444'; dot.style.boxShadow = '0 0 6px #ff4444'; }
}

function stopRecording() {
  if (recognition) { try { recognition.stop(); } catch {} recognition = null; }
  state.isRecording = false;
  const btn = document.getElementById('voice-btn');
  if (btn) { btn.classList.remove('recording'); btn.textContent = '🎙'; }
  document.getElementById('voice-status-label').textContent = 'STANDBY';
  setWaveActive(false);
  const dot = document.getElementById('dot-voice');
  if (dot) { dot.style.background = '#4a7a99'; dot.style.boxShadow = 'none'; }
}

function speak(text) {
  if (!state.voiceEnabled || !window.speechSynthesis) return;
  speechSynthesis.cancel();
  const clean = text.replace(/\*\*/g,'').replace(/\*/g,'').replace(/\n/g,' ').slice(0, 300);
  const utt = new SpeechSynthesisUtterance(clean);
  utt.rate  = 0.93;
  utt.pitch = 1.08;
  utt.volume = 0.85;

  const voices = speechSynthesis.getVoices();
  const preferred = voices.find(v =>
    v.name.includes('Samantha') || v.name.includes('Google UK English Female') ||
    v.name.includes('Karen') || v.name.includes('Moira') || v.lang === 'en-GB'
  );
  if (preferred) utt.voice = preferred;

  utt.onstart = () => {
    state.isSpeaking = true;
    document.getElementById('voice-status-label').textContent = '🔊 ARIA SPEAKING';
    setWaveActive(true);
  };
  utt.onend = utt.onerror = () => {
    state.isSpeaking = false;
    document.getElementById('voice-status-label').textContent = 'STANDBY';
    setWaveActive(false);
  };

  speechSynthesis.speak(utt);
}

// Preload voices
if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices();

// ── Waveform ──────────────────────────────────────────────────────────────────
let waveCtx = null;
let waveData = [];

function buildWaveform() {
  const canvas = document.getElementById('waveform-canvas');
  if (!canvas) return;
  waveCtx = canvas.getContext('2d');
  canvas.width = canvas.parentElement?.offsetWidth - 120 || 600;
  waveData = new Array(80).fill(2);
  animateWave();
}

function animateWave() {
  if (!waveCtx) return;
  const canvas = waveCtx.canvas;
  waveCtx.clearRect(0, 0, canvas.width, canvas.height);

  const active = state.waveActive;
  const W = canvas.width, H = canvas.height;
  const barW = W / waveData.length - 1;

  // Shift and add new value
  waveData.shift();
  const newVal = active
    ? 4 + Math.random() * (H * 0.75)
    : 3 + Math.sin(Date.now() / 400) * 4 + Math.random() * 3;
  waveData.push(newVal);

  // Draw
  waveData.forEach((h, i) => {
    const x = i * (barW + 1);
    const y = (H - h) / 2;
    const progress = i / waveData.length;
    const color = active
      ? `hsl(${180 + progress * 60}, 100%, 55%)`
      : '#007a99';
    waveCtx.fillStyle = color;
    waveCtx.globalAlpha = active ? 0.8 + progress * 0.2 : 0.5;
    waveCtx.fillRect(x, y, barW, h);
  });

  state.waveAnimId = requestAnimationFrame(animateWave);
}

function setWaveActive(active) {
  state.waveActive = active;
}

// ── Emotion System ────────────────────────────────────────────────────────────
const EMOTIONS = {
  neutral:  { mood: '● NEUTRAL',    mouth: 'M63 115 Q80 125 97 115', lbrow: 'M44 63 Q58 57 72 63', rbrow: 'M88 63 Q102 57 116 63', face: '' },
  happy:    { mood: '● HAPPY',      mouth: 'M60 113 Q80 130 100 113', lbrow: 'M44 60 Q58 54 72 60', rbrow: 'M88 60 Q102 54 116 60', face: 'happy' },
  thinking: { mood: '◈ PROCESSING', mouth: 'M68 118 Q80 118 92 118', lbrow: 'M44 60 Q58 54 72 65', rbrow: 'M88 65 Q102 54 116 60', face: 'thinking' },
  alert:    { mood: '⚡ ALERT',      mouth: 'M65 119 Q80 115 95 119', lbrow: 'M44 65 Q58 55 72 61', rbrow: 'M88 61 Q102 55 116 65', face: 'alert' },
  curious:  { mood: '? CURIOUS',    mouth: 'M63 115 Q80 128 97 115', lbrow: 'M44 64 Q58 54 72 62', rbrow: 'M88 60 Q102 57 116 65', face: '' },
};

function setEmotion(name) {
  const e = EMOTIONS[name] || EMOTIONS.neutral;
  state.emotion = name;

  document.getElementById('id-mood').textContent = e.mood;

  const mouth = document.getElementById('aria-mouth');
  const lbrow = document.getElementById('l-brow');
  const rbrow = document.getElementById('r-brow');
  const face  = document.getElementById('face-wrap');

  if (mouth) mouth.setAttribute('d', e.mouth);
  if (lbrow) lbrow.setAttribute('d', e.lbrow);
  if (rbrow) rbrow.setAttribute('d', e.rbrow);
  if (face)  face.className = 'face-wrap' + (e.face ? ' ' + e.face : '');
}

function analyzeAndUpdateEmotion(text) {
  const lower = text.toLowerCase();
  if (/\b(great|wonderful|amazing|excellent|happy|love|fantastic|!)\b/.test(lower)) setEmotion('happy');
  else if (/\b(error|warning|alert|critical|problem|issue)\b/.test(lower)) setEmotion('alert');
  else if (/\b(interesting|fascinating|curious|wonder|perhaps|consider)\b/.test(lower)) setEmotion('curious');
  else setEmotion('neutral');
}

// Blink animation
setInterval(() => {
  const lIris = document.getElementById('l-iris');
  const rIris = document.getElementById('r-iris');
  if (!lIris || !rIris) return;
  lIris.setAttribute('ry', '0.5');
  rIris.setAttribute('ry', '0.5');
  setTimeout(() => {
    lIris.setAttribute('ry', '5');
    rIris.setAttribute('ry', '5');
  }, 150);
}, 4000 + Math.random() * 3000);

// ── Mode Switching ─────────────────────────────────────────────────────────────
function setMode(btn, mode) {
  document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  state.mode = mode;
  const labels = { assistant:'ASST', research:'RSRCH', creative:'CRTV', analysis:'ANLYS', vision:'VIS', mission:'MISS' };
  document.getElementById('meta-mode').textContent  = 'MODE: ' + mode.toUpperCase();
  document.getElementById('sr-mode').textContent    = labels[mode] || mode.toUpperCase();
  notify(`Mode → ${mode.toUpperCase()}`);
  appendLog(`[SYS] Mode switched to ${mode}`);
}

// ── Quick Commands ────────────────────────────────────────────────────────────
function quickCmd(text) {
  document.getElementById('msg-input').value = text;
  sendMsg();
  switchView('chat');
}

// ── Clear Chat ────────────────────────────────────────────────────────────────
function clearChat() {
  state.history = [];
  document.getElementById('messages').innerHTML = '';
  addMessage('aria', "Memory cleared. Fresh conversation started — what would you like to explore?", { silent: true });
  appendLog('[SYS] Chat cleared');
}

// ── Input Utils ───────────────────────────────────────────────────────────────
function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg(); }
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 110) + 'px';
}

// ── Clock ─────────────────────────────────────────────────────────────────────
function startClock() {
  const tick = () => {
    const now = new Date();
    const clockEl = document.getElementById('r-clock');
    const dateEl  = document.getElementById('r-date');
    if (clockEl) clockEl.textContent = now.toTimeString().slice(0, 8);
    if (dateEl)  dateEl.textContent  = now.toDateString().toUpperCase();
  };
  tick();
  setInterval(tick, 1000);
}

// ── Uptime ─────────────────────────────────────────────────────────────────────
function startUptimeCounter() {
  setInterval(() => {
    const secs = Math.floor((Date.now() - state.sessionStart) / 1000);
    const m = Math.floor(secs / 60), s = secs % 60;
    const el = document.getElementById('sr-uptime');
    if (el) el.textContent = m > 0 ? `${m}m ${s}s` : `${s}s`;
  }, 1000);
}

// ── System Vitals ─────────────────────────────────────────────────────────────
const vitals = { cpu: 12, mem: 34, temp: 37.2, net: 'OK' };

function startVitals() {
  setInterval(() => {
    vitals.cpu  = Math.floor(5 + Math.random() * 40);
    vitals.mem  = Math.floor(25 + Math.random() * 35);
    vitals.temp = parseFloat((36 + Math.random() * 3).toFixed(1));
    renderVitals();
  }, 3500);
  renderVitals();
}

function renderVitals() {
  const tpl = `
    <div class="neural-bar-row"><span class="nb-label">CPU</span><div class="nb-bar"><div class="nb-fill" style="width:${vitals.cpu}%;background:linear-gradient(90deg,var(--cyan3),var(--cyan))"></div></div><span class="nb-val">${vitals.cpu}%</span></div>
    <div class="neural-bar-row"><span class="nb-label">RAM</span><div class="nb-bar"><div class="nb-fill" style="width:${vitals.mem}%;background:linear-gradient(90deg,#5a2c99,var(--purple))"></div></div><span class="nb-val">${vitals.mem}%</span></div>
    <div class="neural-bar-row"><span class="nb-label">TEMP</span><div class="nb-bar"><div class="nb-fill" style="width:${(vitals.temp/45*100).toFixed(0)}%;background:linear-gradient(90deg,var(--gold2),var(--gold))"></div></div><span class="nb-val">${vitals.temp}°</span></div>
    <div class="neural-bar-row"><span class="nb-label">NET</span><div class="nb-bar"><div class="nb-fill" style="width:${state.pythonOnline?88:15}%;background:linear-gradient(90deg,var(--green2),var(--green))"></div></div><span class="nb-val">${state.pythonOnline?'ON':'OFF'}</span></div>
  `;
  document.querySelectorAll('[id^="vitals"]').forEach(el => { el.innerHTML = tpl; });
}

// ── Neural Activity Bars ──────────────────────────────────────────────────────
const NEURAL_LAYERS = [
  { label: 'NLP',    color: 'linear-gradient(90deg,var(--cyan3),var(--cyan))',      val: 85 },
  { label: 'ML',     color: 'linear-gradient(90deg,#006633,var(--green))',           val: 71 },
  { label: 'Vision', color: 'linear-gradient(90deg,#5a2c99,var(--purple))',          val: 42 },
  { label: 'Memory', color: 'linear-gradient(90deg,var(--gold2),var(--gold))',       val: 58 },
  { label: 'Voice',  color: 'linear-gradient(90deg,var(--cyan3),var(--cyan))',       val: 30 },
  { label: 'Search', color: 'linear-gradient(90deg,#5a2c99,var(--purple))',          val: 65 },
  { label: 'Neural', color: 'linear-gradient(90deg,var(--gold2),var(--gold))',       val: 78 },
];

function buildNeuralBars() {
  const tpl = () => NEURAL_LAYERS.map(l => `
    <div class="neural-bar-row">
      <span class="nb-label">${l.label}</span>
      <div class="nb-bar"><div class="nb-fill nb-${l.label.toLowerCase()}" style="width:${l.val}%;background:${l.color}"></div></div>
      <span class="nb-val nb-pct-${l.label.toLowerCase()}">${l.val}%</span>
    </div>
  `).join('');

  ['neural-bars-right', 'neural-bars-sys'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = tpl();
  });

  // Animate
  setInterval(() => {
    NEURAL_LAYERS.forEach(l => {
      l.val = Math.max(15, Math.min(98, l.val + (Math.random() * 20 - 10)));
      document.querySelectorAll('.nb-' + l.label.toLowerCase()).forEach(el => {
        el.style.width = l.val.toFixed(0) + '%';
      });
      document.querySelectorAll('.nb-pct-' + l.label.toLowerCase()).forEach(el => {
        el.textContent = l.val.toFixed(0) + '%';
      });
    });
  }, 4000);
}

// ── Right Panel ───────────────────────────────────────────────────────────────
function switchRPanel(name) {
  ['neural','log','update'].forEach(n => {
    document.getElementById('rpanel-' + n)?.classList.toggle('active', n === name);
    document.getElementById('rtab-' + n)?.classList.toggle('active', n === name);
  });
}

// ── Log ───────────────────────────────────────────────────────────────────────
function appendLog(entry) {
  const ts  = new Date().toTimeString().slice(0, 8);
  const line = `[${ts}] ${entry}`;
  ['sys-log-right', 'sys-log-display'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent += (el.textContent ? '\n' : '') + line;
    el.scrollTop = el.scrollHeight;
  });
}

// ── Stats ─────────────────────────────────────────────────────────────────────
function updateStats() {
  document.getElementById('meta-tokens').textContent  = 'TOKENS: ' + state.totalTokens;
  document.getElementById('meta-msgs').textContent    = 'MSGS: ' + state.msgCount;
  document.getElementById('sr-msgs').textContent      = state.msgCount;
  document.getElementById('sr-tokens').textContent    = state.totalTokens;
}

// ── Notification ──────────────────────────────────────────────────────────────
let notifyTimer = null;
function notify(msg) {
  const el = document.getElementById('notification');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(notifyTimer);
  notifyTimer = setTimeout(() => el.classList.remove('show'), 3000);
  if (window.aria) window.aria.notify('ARIA', msg);
}

// ── Self-Update ───────────────────────────────────────────────────────────────
async function triggerSelfUpdate() {
  notify('🔄 Initiating self-update...');
  appendLog('[UPD] Self-update sequence started');
  setEmotion('thinking');
  setWaveActive(true);

  const newVer = bumpVersion(state.version);

  // Simulate update steps with logs
  const steps = [
    'Downloading neural weight delta...',
    'Merging NLP vocabulary updates...',
    'Optimizing ML model parameters...',
    'Refreshing personality matrix...',
    'Updating computer vision kernels...',
    'Compressing and applying changes...',
    'Verifying integrity checksums...',
  ];

  for (const step of steps) {
    await sleep(380);
    appendLog('[UPD] ' + step);
  }

  // Call Electron self-update
  let result = null;
  if (window.aria) result = await window.aria.selfUpdate(newVer);

  // Call Python backend self-update
  const pyResult = await pythonPost('/self-update', { version: newVer }).catch(() => null);

  updateVersion(newVer);
  setWaveActive(false);
  setEmotion('happy');

  const entry = {
    version: newVer,
    time: new Date().toISOString(),
    ml_accuracy: pyResult?.ml_accuracy || 'N/A',
    nlp_confidence: pyResult?.nlp_confidence || 'N/A'
  };
  state.updateLog.push(entry);
  refreshUpdateHistory();

  const msg = `🔄 **Self-Update Complete — ARIA v${newVer}**\n\nAll systems have been optimized:\n- **NLP**: Vocabulary expanded, tokenizer refined\n- **ML**: Neural weights recalibrated (+${(Math.random()*1.5+0.3).toFixed(1)}% accuracy)\n- **Vision**: Edge detection kernels sharpened\n- **Memory**: Index rebuilt and compressed\n- **Personality**: Matrix fine-tuned for contextual awareness\n- **Search**: Index freshness updated\n\nIntegrity check: ✅ All checksums valid. I'm operating at peak capacity.`;

  addMessage('aria', msg);
  appendLog(`[UPD] Complete — v${newVer}`);
  notify(`✅ Updated to ARIA v${newVer}`);
}

function bumpVersion(ver) {
  const parts = ver.split('.').map(Number);
  parts[2]++;
  if (parts[2] >= 10) { parts[2] = 0; parts[1]++; }
  return parts.join('.');
}

function updateVersion(ver) {
  state.version = ver;
  document.getElementById('id-version').textContent = 'v' + ver;
  document.getElementById('sr-version').textContent = ver;
  const cfgVer = document.getElementById('cfg-ver-display');
  if (cfgVer) cfgVer.textContent = ver;
  const bootVer = document.getElementById('boot-ver');
  if (bootVer) bootVer.textContent = 'v' + ver;
}

function refreshUpdateHistory() {
  const el = document.getElementById('update-history');
  if (!el) return;
  el.textContent = state.updateLog.slice(-10).reverse()
    .map(u => `v${u.version} — ${new Date(u.time).toLocaleTimeString()} — ML:${u.ml_accuracy}`)
    .join('\n');
}

// ── Memory ────────────────────────────────────────────────────────────────────
function extractMemory(role, text) {
  const lower = text.toLowerCase();
  const patterns = [
    { re: /remind\w*/i,       tag: 'reminder' },
    { re: /schedul\w*/i,      tag: 'schedule' },
    { re: /weather/i,         tag: 'weather'  },
    { re: /research/i,        tag: 'research' },
    { re: /remember/i,        tag: 'memory'   },
    { re: /my name is (\w+)/i,tag: 'identity' },
    { re: /prefer/i,          tag: 'preference'},
  ];

  patterns.forEach(p => {
    if (p.re.test(text)) {
      const mem = {
        tag: p.tag, role, text: text.slice(0, 80),
        time: new Date().toISOString(), mode: state.mode
      };
      if (!state.memories.find(m => m.text === mem.text)) {
        state.memories.push(mem);
        state.memories = state.memories.slice(-50);
        refreshMemoryView();
        pythonPost('/memory/add', { memory: mem }).catch(() => {});
      }
    }
  });
}

async function saveMemoryToDisk() {
  if (window.aria) {
    await window.aria.saveMemory(state.memories);
    notify('✅ Memory saved to disk');
    appendLog('[MEM] Saved to disk (' + state.memories.length + ' entries)');
  } else {
    try { localStorage.setItem('aria-memory', JSON.stringify(state.memories)); notify('✅ Memory saved'); } catch {}
  }
}

async function loadMemoryFromDisk() {
  try {
    if (window.aria) {
      const m = await window.aria.loadMemory();
      if (m?.length) state.memories = m;
    } else {
      const m = JSON.parse(localStorage.getItem('aria-memory') || '[]');
      if (m.length) state.memories = m;
    }
    refreshMemoryView();
    appendLog('[MEM] Loaded ' + state.memories.length + ' memories');
  } catch {}
}

function clearMemory() {
  state.memories = [];
  refreshMemoryView();
  notify('🗑 Memory cleared');
  appendLog('[MEM] Memory cleared');
}

function refreshMemoryView() {
  const sessionEl = document.getElementById('session-memories');
  const ltEl      = document.getElementById('lt-memories');
  if (!sessionEl || !ltEl) return;

  const recent = state.memories.slice(-10).reverse();
  sessionEl.innerHTML = recent.length
    ? recent.map(m => `<div class="mem-item">[${m.tag?.toUpperCase() || 'MEM'}] ${m.text}</div>`).join('')
    : '<div class="mem-item">No session memories yet.</div>';

  const lt = state.memories.filter(m => ['reminder','schedule','preference','identity'].includes(m.tag));
  ltEl.innerHTML = lt.length
    ? lt.slice(-10).reverse().map(m => `<div class="mem-item">[${m.tag?.toUpperCase()}] ${m.text}</div>`).join('')
    : '<div class="mem-item">No long-term memories stored.</div>';
}

// ── NLP Panel ─────────────────────────────────────────────────────────────────
async function runNLPAnalysis(text) {
  const el = document.getElementById('nlp-panel');
  if (!el) return;

  // Try Python backend first
  const result = await pythonPost('/nlp/analyze', { text }).catch(() => null);
  if (result) {
    el.innerHTML = `
      <div>Intent: <span style="color:var(--cyan)">${result.intent || '-'}</span> (${((result.intent_confidence||0)*100).toFixed(0)}%)</div>
      <div>Sentiment: <span style="color:var(--green2)">${result.sentiment || '-'}</span></div>
      <div>Language: <span style="color:var(--cyan)">${result.language || 'en'}</span></div>
      <div>Words: <span style="color:var(--text2)">${result.word_count || 0}</span></div>
      <div>Entities: <span style="color:var(--purple)">${(result.entities||[]).map(e=>e.text).join(', ') || 'none'}</span></div>
      <div>Question: <span style="color:var(--gold)">${result.question ? 'Yes' : 'No'}</span></div>
    `;
  } else {
    // Fallback local analysis
    const words = text.split(/\s+/);
    el.innerHTML = `
      <div>Words: <span style="color:var(--text2)">${words.length}</span></div>
      <div>Chars: <span style="color:var(--text2)">${text.length}</span></div>
      <div>Question: <span style="color:var(--gold)">${text.includes('?') ? 'Yes' : 'No'}</span></div>
      <div style="color:var(--text3);font-size:9px;margin-top:4px;">Python backend offline — local analysis</div>
    `;
  }
}

// ── System View Refresh ────────────────────────────────────────────────────────
async function refreshSystemView() {
  const status = await pythonPost('/status', {}).catch(() => null);
  if (status) {
    appendLog('[SYS] Python status: v' + status.version + ' uptime=' + status.uptime_seconds + 's');
    const dot = document.getElementById('dot-python');
    if (dot) { dot.style.background = '#00ff88'; dot.style.boxShadow = '0 0 6px #00ff88'; }
  }
  renderVitals();
}

// ── Deep Search ───────────────────────────────────────────────────────────────
async function runDeepSearch() {
  const query = document.getElementById('search-input')?.value?.trim();
  if (!query) return;
  const el = document.getElementById('search-results');
  if (el) el.innerHTML = '<span style="color:var(--cyan3)">Searching...</span>';

  const result = await pythonPost('/search', { query, depth: 3 }).catch(() => null);

  if (result?.results?.length) {
    el.innerHTML = result.results.map(r => `
      <div style="border-bottom:1px solid rgba(0,212,255,0.08);padding:6px 0;">
        <div style="color:var(--cyan);font-size:9px;margin-bottom:2px;">[${r.source}] — ${(r.relevance*100).toFixed(0)}% relevant</div>
        <div>${r.content}</div>
      </div>
    `).join('');
    appendLog(`[SEARCH] "${query}" — ${result.total_found} results in ${result.search_time_ms}ms`);
  } else {
    el.innerHTML = '<span style="color:var(--text3)">Python backend offline. Use chat for deep research.</span>';
  }
}

// ── ML Training Panel ─────────────────────────────────────────────────────────
async function runMLStep() {
  const el = document.getElementById('ml-output');
  if (el) el.textContent = 'Running training step...';
  const result = await pythonPost('/ml/train', {}).catch(() => null);
  if (result) {
    el.textContent = [
      `Loss before: ${result.loss_before}`,
      `Loss after:  ${result.loss_after}`,
      `Improvement: ${result.improvement}`,
      `Accuracy:    ${result.accuracy}%`,
      `Time:        ${new Date(result.timestamp).toLocaleTimeString()}`,
    ].join('\n');
    appendLog(`[ML] Training step — accuracy: ${result.accuracy}%`);
  } else {
    el.textContent = 'Python backend offline.\nML engine simulating locally.';
    appendLog('[ML] Training step (local simulation)');
  }
}

// ── Vision ────────────────────────────────────────────────────────────────────
function activateCamera() {
  const feed = document.getElementById('camera-feed');
  if (!navigator.mediaDevices?.getUserMedia) {
    feed.innerHTML = '<div class="camera-placeholder"><div>Camera not supported in this browser.</div></div>';
    return;
  }
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
      const video = document.createElement('video');
      video.srcObject = stream;
      video.autoplay = true;
      video.style.cssText = 'width:100%;height:100%;object-fit:cover;';
      feed.innerHTML = '';
      feed.appendChild(video);
      appendLog('[CAM] Camera activated');
      notify('📷 Camera active');
    })
    .catch(err => {
      feed.innerHTML = `<div class="camera-placeholder"><div>Camera error: ${err.message}</div></div>`;
    });
}

function captureFrame() {
  const video = document.querySelector('#camera-feed video');
  if (!video) { notify('⚠ Activate camera first'); return; }
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);
  const feed = document.getElementById('camera-feed');
  const img = document.createElement('img');
  img.src = canvas.toDataURL();
  img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
  feed.innerHTML = '';
  feed.appendChild(img);
  appendLog('[CAM] Frame captured');
  notify('📸 Frame captured');
}

async function analyzeFrame() {
  const img = document.querySelector('#camera-feed img');
  const resultsEl = document.getElementById('vision-results');
  const objectsEl = document.getElementById('detected-objects');

  if (!img) { notify('⚠ Capture a frame first'); return; }
  if (resultsEl) resultsEl.innerHTML = '<span style="color:var(--cyan3)">Analyzing...</span>';

  // Try Python backend
  const result = await pythonPost('/vision/analyze', { path: '' }).catch(() => null);

  const data = result || {
    simulated: true,
    faces_detected: Math.floor(Math.random() * 3),
    objects: ['person', 'desk', 'screen', 'chair'].slice(0, 2 + Math.floor(Math.random() * 2)),
    scene: 'indoor',
    brightness: (100 + Math.random() * 100).toFixed(1),
    confidence: (0.7 + Math.random() * 0.25).toFixed(2)
  };

  if (resultsEl) {
    resultsEl.innerHTML = `
      <div style="font-family:var(--mono);font-size:10px;line-height:2;color:var(--text2);">
        <div>Faces detected: <span style="color:var(--cyan)">${data.faces_detected}</span></div>
        <div>Scene: <span style="color:var(--green2)">${data.scene || 'indoor'}</span></div>
        <div>Brightness: <span style="color:var(--gold)">${data.brightness}</span></div>
        <div>Confidence: <span style="color:var(--purple)">${(data.confidence * 100).toFixed(0)}%</span></div>
        ${data.simulated ? '<div style="color:var(--text3);margin-top:4px;">Simulation mode — install OpenCV for real vision</div>' : ''}
      </div>
    `;
  }

  if (objectsEl) {
    objectsEl.innerHTML = (data.objects || []).map(o =>
      `<span class="obj-tag">${o}</span>`
    ).join('');
  }

  appendLog(`[VIS] Analysis complete — ${data.faces_detected} faces, conf ${data.confidence}`);
}

// ── File Upload ───────────────────────────────────────────────────────────────
function openFileUpload() {
  if (window.aria) {
    window.aria.openFile();
    window.aria.on('file-selected', result => {
      if (!result.canceled && result.filePaths[0]) {
        const path = result.filePaths[0];
        document.getElementById('msg-input').value = `Please analyze this file: ${path}`;
        appendLog('[FILE] Selected: ' + path);
      }
    });
  } else {
    document.getElementById('file-input')?.click();
  }
}

document.getElementById('file-input')?.addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    const preview = ev.target.result.toString().slice(0, 500);
    document.getElementById('msg-input').value = `Analyze this file (${file.name}):\n\n${preview}`;
  };
  reader.readAsText(file);
});

// ── Python Backend Utils ──────────────────────────────────────────────────────
async function pythonPost(endpoint, data) {
  if (window.aria) {
    return window.aria.python(endpoint, data);
  }
  const res = await fetch(PY_BASE + endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Python error: ' + res.status);
  return res.json();
}

async function checkPythonBackend() {
  try {
    const r = await fetch(PY_BASE + '/health');
    if (r.ok) {
      state.pythonOnline = true;
      const dot = document.getElementById('dot-python');
      if (dot) { dot.style.background = '#00ff88'; dot.style.boxShadow = '0 0 6px #00ff88'; }
      appendLog('[PY] Python backend connected');
      notify('✅ Python backend online');
    }
  } catch {
    appendLog('[PY] Python backend offline — browser mode active');
  }
}

async function testBackend() {
  await checkPythonBackend();
  const status = await pythonPost('/status', {}).catch(e => ({ error: e.message }));
  notify(status?.error ? '❌ Backend offline' : `✅ Backend v${status.version} online`);
}

// ── Background Tasks ──────────────────────────────────────────────────────────
function scheduleBackgroundTasks() {
  // Periodic NLP + ML updates
  setInterval(() => {
    if (Math.random() < 0.3) {
      pythonPost('/ml/train', {}).catch(() => {});
    }
  }, 60000);

  // Auto-check backend
  setInterval(checkPythonBackend, 30000);

  // Random micro-updates to neural bars
  setInterval(() => {
    const active = state.waveActive;
    if (active) {
      NEURAL_LAYERS.find(l => l.label === 'NLP').val = Math.min(98, 70 + Math.random() * 28);
    }
  }, 1000);
}

// ── Utility ───────────────────────────────────────────────────────────────────
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Boot ──────────────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', runBoot);
window.addEventListener('resize', () => {
  const canvas = document.getElementById('waveform-canvas');
  if (canvas) canvas.width = canvas.parentElement?.offsetWidth - 120 || 600;
});
