/**
 * ARIA Desktop — Language API Frontend Module
 * Handles: language detection, translation, UI localization,
 *          multilingual TTS, language switching, RTL support
 */

'use strict';

// ── Language Registry (mirrors Python backend) ────────────────────────────────
const LANGUAGES = {
  en: { name:"English",     native:"English",          tts:"en-US", rtl:false, flag:"🇬🇧" },
  sw: { name:"Swahili",     native:"Kiswahili",         tts:"sw-KE", rtl:false, flag:"🇰🇪" },
  fr: { name:"French",      native:"Français",          tts:"fr-FR", rtl:false, flag:"🇫🇷" },
  ar: { name:"Arabic",      native:"العربية",            tts:"ar-SA", rtl:true,  flag:"🇸🇦" },
  zh: { name:"Chinese",     native:"中文",              tts:"zh-CN", rtl:false, flag:"🇨🇳" },
  es: { name:"Spanish",     native:"Español",           tts:"es-ES", rtl:false, flag:"🇪🇸" },
  hi: { name:"Hindi",       native:"हिन्दी",             tts:"hi-IN", rtl:false, flag:"🇮🇳" },
  pt: { name:"Portuguese",  native:"Português",         tts:"pt-BR", rtl:false, flag:"🇧🇷" },
  de: { name:"German",      native:"Deutsch",           tts:"de-DE", rtl:false, flag:"🇩🇪" },
  ja: { name:"Japanese",    native:"日本語",             tts:"ja-JP", rtl:false, flag:"🇯🇵" },
  ko: { name:"Korean",      native:"한국어",             tts:"ko-KR", rtl:false, flag:"🇰🇷" },
  ru: { name:"Russian",     native:"Русский",           tts:"ru-RU", rtl:false, flag:"🇷🇺" },
  it: { name:"Italian",     native:"Italiano",          tts:"it-IT", rtl:false, flag:"🇮🇹" },
  nl: { name:"Dutch",       native:"Nederlands",        tts:"nl-NL", rtl:false, flag:"🇳🇱" },
  tr: { name:"Turkish",     native:"Türkçe",            tts:"tr-TR", rtl:false, flag:"🇹🇷" },
  pl: { name:"Polish",      native:"Polski",            tts:"pl-PL", rtl:false, flag:"🇵🇱" },
  vi: { name:"Vietnamese",  native:"Tiếng Việt",        tts:"vi-VN", rtl:false, flag:"🇻🇳" },
  th: { name:"Thai",        native:"ไทย",               tts:"th-TH", rtl:false, flag:"🇹🇭" },
  fa: { name:"Persian",     native:"فارسی",             tts:"fa-IR", rtl:true,  flag:"🇮🇷" },
  he: { name:"Hebrew",      native:"עברית",             tts:"he-IL", rtl:true,  flag:"🇮🇱" },
  id: { name:"Indonesian",  native:"Bahasa Indonesia",  tts:"id-ID", rtl:false, flag:"🇮🇩" },
  ms: { name:"Malay",       native:"Bahasa Melayu",     tts:"ms-MY", rtl:false, flag:"🇲🇾" },
  uk: { name:"Ukrainian",   native:"Українська",        tts:"uk-UA", rtl:false, flag:"🇺🇦" },
  bn: { name:"Bengali",     native:"বাংলা",             tts:"bn-BD", rtl:false, flag:"🇧🇩" },
  ur: { name:"Urdu",        native:"اردو",              tts:"ur-PK", rtl:true,  flag:"🇵🇰" },
  ta: { name:"Tamil",       native:"தமிழ்",             tts:"ta-IN", rtl:false, flag:"🇮🇳" },
  yo: { name:"Yoruba",      native:"Yorùbá",            tts:"yo-NG", rtl:false, flag:"🇳🇬" },
  ha: { name:"Hausa",       native:"Hausa",             tts:"ha-NG", rtl:false, flag:"🇳🇬" },
  am: { name:"Amharic",     native:"አማርኛ",             tts:"am-ET", rtl:false, flag:"🇪🇹" },
  so: { name:"Somali",      native:"Soomaali",          tts:"so-SO", rtl:false, flag:"🇸🇴" },
};

// ── Language Suffix Patterns for Detection ────────────────────────────────────
const LANG_FINGERPRINTS = {
  en: ["the","is","are","was","were","have","this","that","with","from","what","when","how","why"],
  sw: ["na","ni","ya","wa","kwa","za","la","katika","sana","lakini","yake","mimi","wewe"],
  fr: ["le","la","les","de","du","est","sont","avec","dans","pour","que","qui","pas"],
  ar: ["من","في","على","إلى","عن","هذا","كان","ما","هو","هي"],
  zh: ["的","了","在","是","我","有","和","就","不","人"],
  es: ["el","la","los","de","es","son","con","en","para","que","no"],
  de: ["der","die","das","ein","ist","sind","mit","von","für","nicht"],
  pt: ["o","a","de","é","são","com","em","para","que","não"],
  hi: ["है","हैं","और","में","से","को","के","एक","यह"],
  ru: ["и","в","на","не","что","это","как","с","а","за"],
  ja: ["は","が","を","に","で","の","と","も","か","た"],
  ko: ["이","가","을","를","에","의","는","은","로","도"],
  it: ["il","la","di","del","è","sono","con","in","per","che"],
  tr: ["ve","bir","bu","için","ile","de","da","ne","var","ki"],
};

// ── UI Strings (localized) ────────────────────────────────────────────────────
const UI_STRINGS = {
  en: { standby:"STANDBY", listening:"🎙 LISTENING...", speaking:"🔊 ARIA SPEAKING", processing:"ARIA processing...", send:"Send", clear:"Clear", placeholder:"Speak or type to ARIA...", greeting_morning:"Good morning", greeting_afternoon:"Good afternoon", greeting_evening:"Good evening" },
  sw: { standby:"SUBIRI", listening:"🎙 SIKILIZA...", speaking:"🔊 ARIA ANASEMA", processing:"ARIA inafanya kazi...", send:"Tuma", clear:"Futa", placeholder:"Zungumza au andika kwa ARIA...", greeting_morning:"Habari za asubuhi", greeting_afternoon:"Habari za mchana", greeting_evening:"Habari za jioni" },
  fr: { standby:"EN ATTENTE", listening:"🎙 J'ÉCOUTE...", speaking:"🔊 ARIA PARLE", processing:"ARIA traite...", send:"Envoyer", clear:"Effacer", placeholder:"Parlez ou écrivez à ARIA...", greeting_morning:"Bonjour", greeting_afternoon:"Bon après-midi", greeting_evening:"Bonsoir" },
  es: { standby:"EN ESPERA", listening:"🎙 ESCUCHANDO...", speaking:"🔊 ARIA HABLA", processing:"ARIA procesando...", send:"Enviar", clear:"Borrar", placeholder:"Habla o escribe a ARIA...", greeting_morning:"Buenos días", greeting_afternoon:"Buenas tardes", greeting_evening:"Buenas noches" },
  ar: { standby:"الاستعداد", listening:"🎙 أستمع...", speaking:"🔊 آريا تتحدث", processing:"آريا تعالج...", send:"إرسال", clear:"مسح", placeholder:"تحدث أو اكتب لـ ARIA...", greeting_morning:"صباح الخير", greeting_afternoon:"مساء الخير", greeting_evening:"مساء النور" },
  de: { standby:"BEREIT", listening:"🎙 HÖRE ZU...", speaking:"🔊 ARIA SPRICHT", processing:"ARIA verarbeitet...", send:"Senden", clear:"Löschen", placeholder:"Sprechen oder schreiben Sie ARIA...", greeting_morning:"Guten Morgen", greeting_afternoon:"Guten Tag", greeting_evening:"Guten Abend" },
  zh: { standby:"待机", listening:"🎙 聆听中...", speaking:"🔊 ARIA 正在说话", processing:"ARIA 处理中...", send:"发送", clear:"清除", placeholder:"和 ARIA 说话或打字...", greeting_morning:"早上好", greeting_afternoon:"下午好", greeting_evening:"晚上好" },
  hi: { standby:"प्रतीक्षा", listening:"🎙 सुन रही हूँ...", speaking:"🔊 ARIA बोल रही है", processing:"ARIA प्रोसेस कर रही है...", send:"भेजें", clear:"साफ़ करें", placeholder:"ARIA से बात करें या टाइप करें...", greeting_morning:"सुप्रभात", greeting_afternoon:"नमस्ते", greeting_evening:"शुभ संध्या" },
  pt: { standby:"EM ESPERA", listening:"🎙 OUVINDO...", speaking:"🔊 ARIA FALANDO", processing:"ARIA processando...", send:"Enviar", clear:"Limpar", placeholder:"Fale ou escreva para ARIA...", greeting_morning:"Bom dia", greeting_afternoon:"Boa tarde", greeting_evening:"Boa noite" },
  ja: { standby:"待機中", listening:"🎙 聴いています...", speaking:"🔊 ARIA が話しています", processing:"ARIA 処理中...", send:"送信", clear:"クリア", placeholder:"ARIAに話すか入力してください...", greeting_morning:"おはようございます", greeting_afternoon:"こんにちは", greeting_evening:"こんばんは" },
  ru: { standby:"ОЖИДАНИЕ", listening:"🎙 СЛУШАЮ...", speaking:"🔊 ARIA ГОВОРИТ", processing:"ARIA обрабатывает...", send:"Отправить", clear:"Очистить", placeholder:"Говорите или пишите ARIA...", greeting_morning:"Доброе утро", greeting_afternoon:"Добрый день", greeting_evening:"Добрый вечер" },
};

// ── Language State ─────────────────────────────────────────────────────────────
const langState = {
  current: 'en',
  autoDetect: true,
  ttsLocale: 'en-US',
  isRTL: false,
  translationQueue: [],
  detectionHistory: [],
};

// ── Language Detector ─────────────────────────────────────────────────────────
function detectLanguage(text) {
  if (!text || text.length < 3) return { lang: 'en', confidence: 0.5 };

  // Script detection
  if (/[\u0600-\u06FF]/.test(text)) {
    if (/[پچژگ]/.test(text)) return { lang: 'fa', confidence: 0.92 };
    if (/[ٹڈڑ]/.test(text)) return { lang: 'ur', confidence: 0.91 };
    return { lang: 'ar', confidence: 0.93 };
  }
  if (/[\u4E00-\u9FFF]/.test(text)) return { lang: 'zh', confidence: 0.95 };
  if (/[\u3040-\u309F\u30A0-\u30FF]/.test(text)) return { lang: 'ja', confidence: 0.95 };
  if (/[\uAC00-\uD7AF]/.test(text)) return { lang: 'ko', confidence: 0.95 };
  if (/[\u0900-\u097F]/.test(text)) return { lang: 'hi', confidence: 0.93 };
  if (/[\u0400-\u04FF]/.test(text)) return { lang: 'ru', confidence: 0.92 };
  if (/[\u0590-\u05FF]/.test(text)) return { lang: 'he', confidence: 0.93 };
  if (/[\u0E00-\u0E7F]/.test(text)) return { lang: 'th', confidence: 0.94 };
  if (/[\u1200-\u137F]/.test(text)) return { lang: 'am', confidence: 0.93 };

  // Word-frequency fingerprint
  const words = new Set(text.toLowerCase().match(/\b\w+\b/g) || []);
  const scores = {};
  for (const [lang, prints] of Object.entries(LANG_FINGERPRINTS)) {
    const overlap = prints.filter(w => words.has(w)).length;
    scores[lang] = overlap / Math.max(words.size, 1);
  }
  const best = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  const conf = Math.min(best[1] * 3.5, 0.97);
  return { lang: best[0], confidence: conf < 0.05 ? 0.55 : conf, scores };
}

// ── Language Switcher UI ───────────────────────────────────────────────────────
function buildLanguagePanel() {
  const panel = document.getElementById('lang-panel-content');
  if (!panel) return;

  panel.innerHTML = `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
      <div style="font-family:var(--mono);font-size:9px;color:var(--cyan3);letter-spacing:1px;">AUTO-DETECT</div>
      <input type="checkbox" id="lang-auto" checked style="accent-color:var(--cyan);cursor:pointer;"
        onchange="langState.autoDetect=this.checked;ariaLangNotify()">
    </div>
    <div style="font-family:var(--mono);font-size:9px;color:var(--cyan3);letter-spacing:2px;margin-bottom:6px;text-transform:uppercase;">Active Language</div>
    <select id="lang-select" onchange="switchLanguage(this.value)"
      style="width:100%;background:rgba(0,0,0,0.4);border:1px solid var(--cyan3);color:var(--text);padding:6px 8px;font-family:var(--mono);font-size:11px;border-radius:3px;outline:none;cursor:pointer;margin-bottom:10px;">
      ${Object.entries(LANGUAGES).map(([code, info]) =>
        `<option value="${code}" ${code === langState.current ? 'selected' : ''}>${info.flag} ${info.name} — ${info.native}</option>`
      ).join('')}
    </select>
    <div style="font-family:var(--mono);font-size:9px;color:var(--cyan3);letter-spacing:2px;margin-bottom:6px;text-transform:uppercase;">Quick Switch</div>
    <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px;">
      ${['en','sw','fr','es','ar','zh','hi','de','pt','ja','ru','ko'].map(code => {
        const l = LANGUAGES[code];
        return `<button onclick="switchLanguage('${code}')" 
          style="background:rgba(0,212,255,0.05);border:1px solid var(--cyan3);color:var(--text2);padding:3px 7px;border-radius:2px;font-family:var(--mono);font-size:9px;cursor:pointer;transition:all 0.2s;"
          onmouseover="this.style.background='rgba(0,212,255,0.15)'"
          onmouseout="this.style.background='rgba(0,212,255,0.05)'"
          title="${l.name}">${l.flag} ${code.toUpperCase()}</button>`;
      }).join('')}
    </div>
    <div style="font-family:var(--mono);font-size:9px;color:var(--cyan3);letter-spacing:2px;margin-bottom:6px;text-transform:uppercase;">Translate</div>
    <textarea id="translate-input" placeholder="Enter text to translate..."
      style="width:100%;height:60px;background:rgba(0,0,0,0.4);border:1px solid var(--cyan3);color:var(--text);padding:6px 8px;font-family:var(--mono);font-size:11px;border-radius:3px;outline:none;resize:none;"></textarea>
    <div style="display:flex;gap:6px;margin-top:5px;align-items:center;">
      <select id="trans-from" style="flex:1;background:rgba(0,0,0,0.4);border:1px solid var(--cyan3);color:var(--text3);padding:4px;font-family:var(--mono);font-size:9px;border-radius:3px;outline:none;">
        <option value="auto">Auto-detect</option>
        ${Object.entries(LANGUAGES).slice(0,12).map(([c,l])=>`<option value="${c}">${l.flag} ${c.toUpperCase()}</option>`).join('')}
      </select>
      <span style="color:var(--cyan3);font-size:12px;">→</span>
      <select id="trans-to" style="flex:1;background:rgba(0,0,0,0.4);border:1px solid var(--cyan3);color:var(--text3);padding:4px;font-family:var(--mono);font-size:9px;border-radius:3px;outline:none;">
        ${Object.entries(LANGUAGES).map(([c,l])=>`<option value="${c}" ${c===langState.current?'selected':''}>${l.flag} ${c.toUpperCase()}</option>`).join('')}
      </select>
      <button onclick="runTranslation()" style="background:rgba(0,212,255,0.1);border:1px solid var(--cyan3);color:var(--cyan);padding:4px 8px;font-family:var(--mono);font-size:9px;border-radius:3px;cursor:pointer;">GO</button>
    </div>
    <div id="translation-output" style="margin-top:6px;min-height:40px;background:rgba(0,0,0,0.3);border:1px solid rgba(0,212,255,0.15);border-radius:3px;padding:6px 8px;font-size:11px;color:var(--text2);font-family:var(--mono);display:none;"></div>
    <div style="margin-top:10px;" id="lang-detect-display"></div>
  `;
}

function switchLanguage(code) {
  if (!LANGUAGES[code]) return;
  const prev = langState.current;
  langState.current = code;
  langState.ttsLocale = LANGUAGES[code].tts;
  langState.isRTL = LANGUAGES[code].rtl;

  // Update select
  const sel = document.getElementById('lang-select');
  if (sel) sel.value = code;

  // Apply RTL to chat area
  const messages = document.getElementById('messages');
  const input    = document.getElementById('msg-input');
  if (messages) messages.style.direction = langState.isRTL ? 'rtl' : 'ltr';
  if (input)    input.style.direction    = langState.isRTL ? 'rtl' : 'ltr';

  // Update placeholder
  const strings = UI_STRINGS[code] || UI_STRINGS.en;
  if (input) input.placeholder = strings.placeholder;

  // Update voice status label
  const vsLabel = document.getElementById('voice-status-label');
  if (vsLabel) vsLabel.textContent = strings.standby;

  // Update language indicator in title bar
  updateLangIndicator(code);

  // Reload UI strings
  applyUIStrings(code);

  // Update TTS recognition language
  if (window.recognition) window.recognition.lang = langState.ttsLocale;

  if (prev !== code) {
    const flag = LANGUAGES[code].flag;
    const name = LANGUAGES[code].name;
    ariaLangNotify(`${flag} Language switched to ${name}`);
    appendLog(`[LANG] Switched to ${code} (${name})`);

    // Fetch strings from Python backend if available
    pythonFetchLangStrings(code);
  }
}

function applyUIStrings(code) {
  const s = UI_STRINGS[code] || UI_STRINGS.en;
  // Update dynamic labels
  const labels = {
    'voice-status-label': s.standby,
  };
  for (const [id, val] of Object.entries(labels)) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }
}

function updateLangIndicator(code) {
  let indicator = document.getElementById('lang-indicator');
  if (!indicator) {
    indicator = document.createElement('span');
    indicator.id = 'lang-indicator';
    indicator.style.cssText = 'font-family:var(--mono);font-size:9px;color:var(--gold);margin-left:8px;padding:2px 6px;background:rgba(255,215,0,0.08);border:1px solid rgba(255,215,0,0.2);border-radius:2px;cursor:pointer;';
    indicator.onclick = () => switchView('language');
    const tbLeft = document.querySelector('.tb-left');
    if (tbLeft) tbLeft.appendChild(indicator);
  }
  const info = LANGUAGES[code];
  indicator.textContent = `${info.flag} ${code.toUpperCase()}`;
  indicator.title = `Active language: ${info.name} — click to change`;
}

async function pythonFetchLangStrings(code) {
  try {
    const result = await pythonPost(`/language/ui-strings/${code}`, {});
    if (result?.strings) appendLog(`[LANG] UI strings loaded for ${code}`);
  } catch {}
}

function ariaLangNotify(msg) {
  if (msg) notify(msg);
}

// ── Auto-detection on input ───────────────────────────────────────────────────
let detectTimeout = null;
function autoDetectOnInput(text) {
  if (!langState.autoDetect || text.length < 6) return;
  clearTimeout(detectTimeout);
  detectTimeout = setTimeout(async () => {
    const result = detectLanguage(text);
    if (result.confidence > 0.6 && result.lang !== langState.current) {
      // Ask Python backend to confirm
      const pyResult = await pythonPost('/language/detect', { text }).catch(() => result);
      const detected = pyResult?.lang || result.lang;
      const conf = pyResult?.confidence || result.confidence;

      if (conf > 0.65 && detected !== langState.current) {
        showLangSuggestion(detected, conf);
      }
      updateLangDetectDisplay(pyResult || result);
    }
  }, 600);
}

function showLangSuggestion(code, confidence) {
  const lang = LANGUAGES[code];
  if (!lang) return;

  let banner = document.getElementById('lang-suggestion');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'lang-suggestion';
    banner.style.cssText = `
      position:fixed;bottom:80px;left:50%;transform:translateX(-50%);
      background:var(--bg2);border:1px solid var(--gold);color:var(--gold);
      padding:8px 16px;border-radius:4px;font-family:var(--mono);font-size:11px;
      z-index:500;display:flex;align-items:center;gap:12px;
      box-shadow:0 0 20px rgba(255,215,0,0.2);animation:msgIn 0.3s ease-out;
    `;
    document.body.appendChild(banner);
  }
  banner.innerHTML = `
    ${lang.flag} ${lang.name} detected (${(confidence * 100).toFixed(0)}%)
    <button onclick="switchLanguage('${code}');hideLangSuggestion()" 
      style="background:rgba(255,215,0,0.15);border:1px solid rgba(255,215,0,0.4);color:var(--gold);padding:3px 10px;border-radius:3px;font-family:var(--mono);font-size:10px;cursor:pointer;">
      SWITCH
    </button>
    <button onclick="hideLangSuggestion()"
      style="background:transparent;border:none;color:var(--text3);cursor:pointer;font-size:14px;">✕</button>
  `;
  banner.style.display = 'flex';
  clearTimeout(banner._timeout);
  banner._timeout = setTimeout(hideLangSuggestion, 6000);
}

function hideLangSuggestion() {
  const b = document.getElementById('lang-suggestion');
  if (b) b.style.display = 'none';
}

function updateLangDetectDisplay(result) {
  const el = document.getElementById('lang-detect-display');
  if (!el) return;
  const lang = LANGUAGES[result.lang] || {};
  el.innerHTML = `
    <div style="font-family:var(--mono);font-size:9px;color:var(--text3);line-height:1.8;">
      <div>Detected: <span style="color:var(--cyan)">${lang.flag || ''} ${result.name || result.lang}</span></div>
      <div>Confidence: <span style="color:var(--green2)">${((result.confidence||0)*100).toFixed(0)}%</span></div>
      ${result.rtl ? '<div style="color:var(--gold)">RTL script</div>' : ''}
    </div>
  `;
}

// ── Translation ───────────────────────────────────────────────────────────────
async function runTranslation() {
  const input  = document.getElementById('translate-input')?.value?.trim();
  const from   = document.getElementById('trans-from')?.value || 'auto';
  const to     = document.getElementById('trans-to')?.value   || 'en';
  const outEl  = document.getElementById('translation-output');

  if (!input || !outEl) return;
  outEl.style.display = 'block';
  outEl.textContent = 'Translating...';
  outEl.style.color = 'var(--cyan3)';

  // Try Python backend
  const result = await pythonPost('/language/translate', {
    text: input, target: to, source: from
  }).catch(() => null);

  if (result?.translated) {
    outEl.textContent = result.translated;
    outEl.style.color = 'var(--text)';
    outEl.style.direction = LANGUAGES[to]?.rtl ? 'rtl' : 'ltr';
    appendLog(`[LANG] Translated ${result.source_lang}→${to}: "${input.slice(0,30)}"`);
  } else if (result?.method === 'claude_required' && result?.prompt) {
    // Use Claude API for full translation
    outEl.textContent = 'Asking ARIA...';
    const translation = await askAriaForTranslation(result.prompt);
    outEl.textContent = translation;
    outEl.style.color = 'var(--text)';
    outEl.style.direction = LANGUAGES[to]?.rtl ? 'rtl' : 'ltr';
  } else {
    // Full fallback: build prompt for Claude
    const fromName = from === 'auto' ? 'detected language' : (LANGUAGES[from]?.name || from);
    const toName   = LANGUAGES[to]?.name || to;
    const prompt   = `Translate this from ${fromName} to ${toName}. Reply with ONLY the translation:\n\n${input}`;
    const translation = await askAriaForTranslation(prompt);
    outEl.textContent = translation;
    outEl.style.color = 'var(--text)';
  }
}

async function askAriaForTranslation(prompt) {
  try {
    const apiKey = state?.apiKey || document.getElementById('cfg-apikey')?.value;
    if (!apiKey) return '[API key required for full translation]';

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await res.json();
    return data.content?.[0]?.text || '[Translation failed]';
  } catch (e) {
    return '[Translation error: ' + e.message + ']';
  }
}

// ── Multilingual TTS ──────────────────────────────────────────────────────────
function speakInLanguage(text, langCode) {
  if (!window.speechSynthesis) return;
  speechSynthesis.cancel();

  const locale = LANGUAGES[langCode]?.tts || 'en-US';
  const clean  = text.replace(/\*\*/g,'').replace(/\*/g,'').replace(/\n/g,' ').slice(0, 300);
  const utt    = new SpeechSynthesisUtterance(clean);

  utt.lang   = locale;
  utt.rate   = 0.93;
  utt.pitch  = 1.05;
  utt.volume = 0.85;

  // Find best matching voice for this language
  const voices = speechSynthesis.getVoices();
  const langPrefix = locale.split('-')[0];
  const match = voices.find(v => v.lang === locale) ||
                voices.find(v => v.lang.startsWith(langPrefix)) ||
                voices.find(v => v.default);
  if (match) utt.voice = match;

  const vsLabel = document.getElementById('voice-status-label');
  const strings = UI_STRINGS[langCode] || UI_STRINGS.en;

  utt.onstart = () => {
    if (vsLabel) vsLabel.textContent = strings.speaking;
    if (typeof setWaveActive === 'function') setWaveActive(true);
  };
  utt.onend = utt.onerror = () => {
    if (vsLabel) vsLabel.textContent = strings.standby;
    if (typeof setWaveActive === 'function') setWaveActive(false);
  };

  speechSynthesis.speak(utt);
}

// ── Language View (full panel) ────────────────────────────────────────────────
function injectLanguageView() {
  const viewContainer = document.getElementById('view-container');
  if (!viewContainer || document.getElementById('view-language')) return;

  const view = document.createElement('div');
  view.id = 'view-language';
  view.className = 'view';
  view.innerHTML = `
    <div class="view-header">LANGUAGE & TRANSLATION CENTER — 30 LANGUAGES</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;padding:14px;overflow-y:auto;flex:1;">
      
      <!-- Language Switcher -->
      <div style="background:var(--bg2);border:1px solid var(--cyan3);border-radius:4px;padding:12px;">
        <div class="panel-title">LANGUAGE CONTROL</div>
        <div id="lang-panel-content"></div>
      </div>

      <!-- Available Languages Grid -->
      <div style="background:var(--bg2);border:1px solid var(--cyan3);border-radius:4px;padding:12px;">
        <div class="panel-title">ALL 30 SUPPORTED LANGUAGES</div>
        <div style="display:flex;flex-direction:column;gap:3px;overflow-y:auto;max-height:400px;">
          ${Object.entries(LANGUAGES).map(([code, info]) => `
            <div onclick="switchLanguage('${code}')"
              style="display:flex;align-items:center;gap:8px;padding:5px 8px;border-radius:3px;cursor:pointer;border:1px solid transparent;transition:all 0.2s;"
              id="lang-item-${code}"
              onmouseover="this.style.background='rgba(0,212,255,0.08)';this.style.borderColor='var(--cyan3)'"
              onmouseout="this.style.background='transparent';this.style.borderColor='transparent'">
              <span style="font-size:16px;">${info.flag}</span>
              <div>
                <div style="font-family:var(--mono);font-size:10px;color:var(--text);">${info.name}</div>
                <div style="font-family:var(--mono);font-size:9px;color:var(--text3);">${info.native} · ${info.tts}${info.rtl?' · RTL':''}</div>
              </div>
              <div style="margin-left:auto;font-family:var(--mono);font-size:9px;color:var(--cyan3);">${code.toUpperCase()}</div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Detection History -->
      <div style="background:var(--bg2);border:1px solid var(--cyan3);border-radius:4px;padding:12px;display:flex;flex-direction:column;gap:8px;">
        <div class="panel-title">DETECTION HISTORY</div>
        <div id="detect-history" style="flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:4px;max-height:180px;">
          <div style="font-family:var(--mono);font-size:9px;color:var(--text3);">No detections yet.</div>
        </div>
        <div class="panel-title" style="margin-top:8px;">VOICE LANGUAGES AVAILABLE</div>
        <div id="voice-lang-list" style="font-family:var(--mono);font-size:9px;color:var(--text3);line-height:1.8;overflow-y:auto;max-height:120px;"></div>
      </div>
    </div>
  `;

  viewContainer.appendChild(view);

  // Add language button to title bar
  const tbRight = document.querySelector('.tb-right');
  if (tbRight && !document.getElementById('btn-view-language')) {
    const btn = document.createElement('button');
    btn.id = 'btn-view-language';
    btn.className = 'tb-btn';
    btn.textContent = '🌐';
    btn.title = 'Languages';
    btn.onclick = () => switchView('language');
    tbRight.insertBefore(btn, tbRight.querySelector('.tb-sep'));
  }

  buildLanguagePanel();
  loadVoiceLanguages();
}

function loadVoiceLanguages() {
  const el = document.getElementById('voice-lang-list');
  if (!el) return;
  if (!window.speechSynthesis) {
    el.textContent = 'Speech synthesis not available.';
    return;
  }
  const voices = speechSynthesis.getVoices();
  if (voices.length === 0) {
    el.textContent = 'Loading voices...';
    speechSynthesis.onvoiceschanged = loadVoiceLanguages;
    return;
  }
  const langs = [...new Set(voices.map(v => v.lang))].slice(0, 20);
  el.innerHTML = langs.map(l => {
    const code = l.split('-')[0];
    const info = LANGUAGES[code] || {};
    return `<div style="color:var(--text2);">${info.flag || '🔤'} ${l} — ${info.name || code}</div>`;
  }).join('');
}

// ── Detection History ─────────────────────────────────────────────────────────
function addDetectionToHistory(result) {
  langState.detectionHistory.unshift({
    ...result,
    time: new Date().toLocaleTimeString()
  });
  langState.detectionHistory = langState.detectionHistory.slice(0, 10);

  const el = document.getElementById('detect-history');
  if (!el) return;
  el.innerHTML = langState.detectionHistory.map(d => {
    const info = LANGUAGES[d.lang] || {};
    return `<div style="display:flex;gap:6px;font-family:var(--mono);font-size:9px;padding:3px;border-bottom:1px solid rgba(0,212,255,0.06);">
      <span>${info.flag || '🔤'}</span>
      <span style="color:var(--cyan)">${d.name || d.lang}</span>
      <span style="color:var(--green2)">${((d.confidence||0)*100).toFixed(0)}%</span>
      <span style="color:var(--text3);margin-left:auto;">${d.time}</span>
    </div>`;
  }).join('');
}

// ── Integration with app.js ───────────────────────────────────────────────────

// Patch the existing speak() function to use current language
const _originalSpeak = window.speak;
window.speakMultiLang = function(text) {
  speakInLanguage(text, langState.current);
};

// Patch input to auto-detect language
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    injectLanguageView();
    switchLanguage('en'); // Default

    const input = document.getElementById('msg-input');
    if (input) {
      input.addEventListener('input', e => autoDetectOnInput(e.target.value));
    }

    // Try to fetch language list from Python backend
    pythonPost('/language/list', {})
      .then(r => appendLog(`[LANG] Backend: ${r.total} languages available`))
      .catch(() => appendLog('[LANG] Running in client-only language mode'));

  }, 1500);
});

// Build multilingual system prompt instruction
function getLangSystemAddon(langCode) {
  const addons = {
    sw: "Jibu kwa Kiswahili sanifu. Wewe ni ARIA.",
    fr: "Réponds en français naturel. Tu es ARIA.",
    es: "Responde en español natural. Eres ARIA.",
    ar: "أجب باللغة العربية الفصحى. أنت ARIA.",
    de: "Antworte auf natürlichem Deutsch. Du bist ARIA.",
    zh: "用自然的中文回答。你是ARIA。",
    hi: "स्वाभाविक हिन्दी में उत्तर दें। आप ARIA हैं।",
    pt: "Responda em português natural. Você é ARIA.",
    ja: "自然な日本語で答えてください。あなたはARIAです。",
    ko: "자연스러운 한국어로 답하세요. 당신은 ARIA입니다.",
    ru: "Отвечай на естественном русском. Ты ARIA.",
    it: "Rispondi in italiano naturale. Sei ARIA.",
    tr: "Doğal Türkçe ile cevap ver. Sen ARIA'sın.",
  };
  return addons[langCode] || '';
}

// Expose for app.js integration
window.langAPI = {
  detect:         detectLanguage,
  switch:         switchLanguage,
  getCurrent:     () => langState.current,
  getLocale:      () => langState.ttsLocale,
  isRTL:          () => langState.isRTL,
  getUIStrings:   (code) => UI_STRINGS[code] || UI_STRINGS.en,
  speak:          speakInLanguage,
  getSystemAddon: getLangSystemAddon,
  addHistory:     addDetectionToHistory,
};
